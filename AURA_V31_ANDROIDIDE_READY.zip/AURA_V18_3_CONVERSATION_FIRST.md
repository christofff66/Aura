# Aura V18.3 — Conversation First

## Principes
- Le nom de l’assistante est strictement **Aura** (A-U-R-A).
- La conversation principale est persistante dans le stockage local.
- Chaque message utilisateur et chaque réponse IA sont conservés dans le même fil `main` par défaut.
- Le contexte envoyé à OpenAI reprend les 40 derniers échanges du fil courant, plus les mémoires et préférences Aura.
- Un nouveau fil est possible volontairement, mais ne remplace pas la conversation principale.
- Les exports ChatGPT/OpenAI peuvent être importés depuis Android en JSON ou ZIP. Aura reconnaît la structure `conversations.json` de l’export ChatGPT et conserve les conversations importées comme fils séparés avec leur titre, date et provenance.
- Les anciennes conversations peuvent être ouvertes depuis **Archives & imports** puis utilisées comme contexte du fil sélectionné.
- L’interface est conversation-first : sur téléphone, la conversation est la surface principale et les plannings, tâches, courses, repas, mémoire, archives et préférences sont regroupés dans le petit menu ☰.
- La voix Android injecte le texte reconnu dans le même fil et l’envoie automatiquement à Aura.

## Connexion OpenAI
Le chemin Android direct reste disponible avec la clé API stockée dans le stockage sécurisé. Le Gateway reste facultatif. Le modèle par défaut reste `gpt-5.6-luna`.

## Limite volontaire
L’import nécessite que l’utilisateur sélectionne/exporte les archives depuis ChatGPT : Aura ne peut pas lire directement les conversations privées de l’application ChatGPT sans export ou connexion explicitement autorisée.
