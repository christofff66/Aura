# Déploiement Aura V9

## Architecture recommandée

Android → HTTPS → Aura Gateway → SDK fournisseur → modèle.

Le Gateway peut être hébergé sur un PC, un NAS, un VPS ou un serveur cloud. Pour un test local sur le même réseau, l'URL HTTP LAN peut être utilisée, mais HTTPS est recommandé dès que le trafic quitte le réseau local.

## Fournisseurs

- OpenAI : SDK officiel TypeScript/JavaScript + Responses API.
- Anthropic : SDK officiel TypeScript + Messages API.
- Gemini : SDK officiel Google GenAI + Interactions API.

Les clés fournisseurs restent dans le Gateway. Ne pas mettre une clé fournisseur permanente dans l'APK.
