# Aura — registre de capacités et plugins V1

Les SDK, connecteurs et plugins sont traités comme des **capacités externes** du noyau. Aura ne doit pas embarquer tous les SDK possibles dans l’APK : elle conserve un registre de capacités et utilise un gateway/plug-in compatible lorsque nécessaire.

Une capacité doit déclarer : identité, version, fournisseur, opérations, permissions, données accessibles, niveau d’autonomie, méthode de vérification et journalisation.

Le registre permet notamment d’ajouter : fournisseurs IA, calendrier, messagerie, téléphonie, notifications, stockage, recherche, domotique et futurs connecteurs.

L’évolution de l’interface peut donc découvrir une nouvelle capacité et proposer une surface UI adaptée, sous le contrôle de Christophe.
