# Aura — architecture de connexion IA V1

## Décision

Aura sépare **le noyau** de **son fournisseur d'intelligence**.

### Mode recommandé : Gateway

Android → Aura Gateway → SDK officiel du fournisseur → modèle IA.

Cela permet :
- OpenAI aujourd'hui ;
- Claude demain ;
- Gemini demain ;
- changement de modèle sans migration de la mémoire Aura ;
- centralisation des secrets et des politiques ;
- journalisation et contrôle des coûts ;
- évolution future vers plusieurs modèles spécialisés.

### Mode local

Android peut continuer à fonctionner sans connexion IA : mémoire locale, tâches, rappels, import/export et noyau Aura restent disponibles.

### Mode direct

Un mode direct peut exister pour développement/test avec des identifiants gérés par l'utilisateur, mais il n'est **pas le mode de distribution recommandé**. Les clés OpenAI ne doivent pas être exposées dans une application cliente ; elles doivent être conservées côté serveur ou dans un gestionnaire de secrets. Voir la documentation officielle OpenAI.

## Abstraction

L'interface Aura parle à un contrat unique :

`/v1/aura { provider, model, input } -> { provider, model, text }`

Le fournisseur devient une capacité interchangeable, pas une dépendance du noyau.
