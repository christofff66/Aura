# Aura V24 — Conversation Core

V24 makes the continuous conversation the primary workspace.

## Design

- The user sees essentially only the conversation.
- Aura keeps the same persistent conversation id by default.
- Context, verbatim, memory, preferences, actions, plugins and imports remain stored behind the conversation.
- Temporary activity is shown as a floating bubble above the conversation and disappears automatically.
- Secondary modules remain accessible from the compact menu.

## Engine abstraction

The conversation is independent from the selected AI provider. The local `conversation_id` is preserved when provider/model preferences change. The current Android transport still uses the configured gateway/OpenAI transport; V24 does **not** claim to reuse a private ChatGPT application session.

Future adapters can map the same Aura conversation/context contract to another authorized engine without rebuilding Aura's local memory.

## Plugin construction

The `:aura-sdk` module remains embedded in the project. Aura can receive an `AURA_PLUGIN_SPEC`, store it as an inactive plugin proposal, and activate it only after explicit authorization. The SDK is isolated from the app kernel.
