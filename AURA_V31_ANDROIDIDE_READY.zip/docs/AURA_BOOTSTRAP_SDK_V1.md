# Aura Bootstrap SDK V1

Aura embarque désormais un petit SDK généraliste, gratuit et MIT, indépendant des fournisseurs IA.

## Rôle
- fournir une API stable pour les capacités/plugins ;
- décrire permissions et dépendances ;
- encadrer les actions avec des états vérifiables ;
- permettre de représenter une évolution d'interface et les éventuelles modifications du noyau nécessaires ;
- séparer le droit d'exécuter une capacité du simple fait qu'elle est installée.

## Fournisseurs IA
Les SDK OpenAI/Anthropic/Google restent côté Gateway/backend. Ils ne sont pas copiés dans l'APK : les embarquer ne donnerait pas à Aura une capacité d'évolution et risquerait d'exposer des secrets. Aura utilise le SDK embarqué comme couche de contrat/orchestration.

## Évolution future
MCP est retenu comme protocole d'interopérabilité externe pour outils/sources. L'implémentation complète peut être ajoutée comme dépendance/adaptateur sans changer le noyau.
