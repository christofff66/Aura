# Aura — découverte de capacités V1

Le runtime distingue :
- capacité connue ;
- capacité disponible/configurée ;
- capacité proposée ;
- capacité autorisée ;
- capacité installée/intégrée ;
- capacité activée ;
- capacité vérifiée.

Une proposition ne vaut jamais autorisation. Les permissions sont non transférables. L'intégration d'un SDK ou plugin doit conserver son fournisseur, sa version, ses permissions, ses données accessibles et sa méthode de vérification.

## SDK fournisseurs
Le Gateway est conçu pour accueillir les SDK officiels. Les versions concrètes sont gérées par les dépendances du Gateway et doivent être mises à jour/testées séparément. Pour Gemini, le SDK officiel actuel est `@google/genai`; la documentation Google recommande ce SDK plutôt que l'ancien `@google/generative-ai`. OpenAI et Anthropic restent également des providers distincts du noyau Aura.
