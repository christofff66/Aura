# Aura V18.2 — Modular Workspace

## Objectif
V18.2 transforme le noyau en plateforme: modules, bus d'événements, tableau de bord réorganisable et propositions de modules.

## Échanges noyau ↔ modules
`AuraEventBus` transporte des événements typés entre le noyau et les modules. Un module déclare les événements consommés/émis et ses secrets/permissions. Le bus ne donne aucune permission supplémentaire.

Exemples d'événements: `data.updated`, `ui.card.request`, `calculation.result`, `module.status`, `conversation.context`.

## Interface évolutive
Le tableau de bord est décrit par un manifeste local. Les cartes peuvent être déplacées, redimensionnées, masquées, affichées, épinglées et réinitialisées. La disposition est persistante et doit rester réversible.

Le choix s'inspire des layouts adaptatifs Jetpack/Material: adaptation à la taille de fenêtre, panneaux redimensionnables et logique par tailles plutôt que coordonnées rigides.

## ORA
ORA peut produire des cartes de visualisation: texte, chiffre, tableau, graphique, schéma ou résultat de calcul. Une carte est un consommateur d'événements et peut être placée où l'utilisateur le souhaite.

## Évolution contrôlée
Un module déclaré/configurable peut être activé sans modifier le noyau. L'installation de nouveau code arbitraire n'est pas exécutée silencieusement. Une évolution nécessitant le noyau passe par la procédure d'autorisation, sauvegarde, vérification et retour arrière d'Aura.

## Gradle
Le projet contient `gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar` et `gradle-wrapper.properties`. Le wrapper télécharge Gradle 8.9 dans le cache utilisateur s'il n'est pas présent, puis lance la compilation.
