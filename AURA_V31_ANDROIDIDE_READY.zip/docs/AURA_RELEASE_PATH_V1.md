# Aura — chemin vers une APK réellement utilisable

Objectif : passer du projet source à une APK installable sans modifier le code à la main.

Chaîne :

besoin de Christophe → évolution proposée par Aura → validation explicite → nouvelle version → build CI → APK → installation → retour d'expérience → évolution suivante.

La version 17 constitue la première Release Candidate de cette chaîne.

## Contrôle de version

- version applicative : 1.17.0
- versionCode : 17
- historique Aura conservé dans les données de l'application
- rollback conceptuel conservé par l'atelier de construction

## Sécurité

Une évolution du noyau ne devient pas active uniquement parce qu'elle a été construite.
Elle doit être proposée, explicitement autorisée, testée et vérifiée.
