# Aura V25 — Conversation only

## Objective
The visible workspace is only the continuous Aura conversation. Secondary modules remain in the project and data model but are not exposed from the main menu.

## Scrolling
The conversation stream is a dedicated vertically scrollable surface with touch momentum and automatic scroll-to-bottom behavior.

## ChatGPT continuation
If the OpenAI API used by Aura is unavailable because of exhausted API credits, Aura can launch the official ChatGPT Android application when installed, or open chatgpt.com otherwise. This does **not** claim to programmatically attach to a private ChatGPT session; ChatGPT and API billing are separate.

## Activity bubble
Transient activity messages remain outside the transcript and disappear automatically.

## Plugins
The :aura-sdk module and plugin factory remain embedded; hiding them from the main interface does not delete them.
