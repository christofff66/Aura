# Aura V18 — Architecture modulaire

## Objectif
Le noyau Aura ne doit pas être recompilé pour chaque nouvelle intégration. Les capacités sont décrites par des manifests, enregistrées dans le registre et activées séparément.

## Règles
- Le noyau définit les règles et les permissions de fond.
- Un module déclare son identité, sa version, ses besoins, ses secrets et ses données.
- L'installation/configuration d'un module ne donne pas automatiquement de nouveaux droits au noyau.
- Les secrets sont stockés par `SecretStore` avec Android Keystore.
- Les secrets ne sont jamais exposés au JavaScript de l'interface.
- Une évolution nécessitant une modification du noyau reste soumise à l'autorisation explicite de l'utilisateur.
- Un module déjà prévu par le système peut être activé/configuré après installation sans reconstruire l'APK.

## Module Linky
`energy.linky` est le premier module de démonstration. Il prévoit un token de passerelle et les données suivantes : consommation quotidienne, courbe de charge, puissance maximale et production photovoltaïque si disponible.

Le module ne prétend pas fournir du temps réel : le transport choisi détermine la fréquence de mise à jour.

## Extension future
Le manifest permet d'ajouter d'autres connecteurs sans modifier la structure du noyau : calendrier, météo, objets connectés, services numériques, etc.
