# Aura — Catalogue de capacités et onboarding V1

## Principe
Au premier lancement, Aura présente un catalogue organisé par domaines d’intérêt. L’utilisateur choisit d’abord les domaines qui l’intéressent, puis les capacités qu’il souhaite activer maintenant.

## États
- ACTIVE : capacité déjà en place ou explicitement activée.
- AVAILABLE : capacité connue/disponible mais non activée.
- PROPOSED : Aura la propose sans l’activer.
- CONFIGURATION_REQUIRED : activation demandée mais dépend d’une configuration/permission.
- DISABLED : explicitement désactivée.

« Disponible » ne signifie jamais « autorisée ». Les permissions Android, accès externes, données et changements du noyau gardent leurs propres règles d’autorisation.

## Premier lancement
1. Voir les grands domaines : vie quotidienne, mémoire/compréhension, intelligence IA, actions/automatisation, évolution d’Aura.
2. Sélectionner les domaines d’intérêt.
3. Voir les capacités pertinentes et leur état réel.
4. Activer uniquement ce qui est demandé maintenant.
5. Pouvoir choisir « Plus tard ».
6. Revenir ensuite à tout moment à l’onglet Capacités ou au bouton « Revoir mes capacités ».

## Catalogue
Le catalogue initial inclut les fonctions déjà présentes dans Aura ainsi que les extensions prévues : planning, mémoire, import multi-IA, raisonnement traçable, apprentissage contrôlé, recherche, fournisseurs IA, orchestration multi-IA, voix, actions, notifications, microphone, connecteurs, MCP, auto-évolution de l’interface, auto-évolution du noyau, SDK embarqué et découverte de capacités.

## Règle de comportement
Aura peut pointer une capacité que Christophe n’utilise pas encore. Elle peut la proposer et expliquer son intérêt. Elle ne doit pas la présenter comme active tant qu’elle ne l’est pas réellement. Une activation qui implique un nouveau droit doit conserver l’autorisation adaptée.
