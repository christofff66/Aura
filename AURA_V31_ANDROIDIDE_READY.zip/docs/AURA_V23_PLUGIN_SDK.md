# Aura V23 — bulle d'activité et SDK de plugins

## Interface
La conversation reste la seule information persistante affichée sur l'écran principal. Les états temporaires d'Aura apparaissent dans une petite bulle flottante au-dessus de l'interface :
- Je prépare le contexte…
- J'envoie à ChatGPT…
- Je reçois la réponse…
- Je prépare le plugin proposé…
- J'applique les actions autorisées…
- Réponse reçue.

La bulle disparaît automatiquement après quelques secondes et n'est pas enregistrée dans le verbatim.

## SDK embarqué
Le module `:aura-sdk` est inclus et déclaré comme dépendance de `:app`. Il fournit un contrat de plugin (`AuraPlugin`), un contexte contrôlé (`AuraPluginContext`), un constructeur (`AuraPluginBuilder`) et un registre (`AuraPluginRegistry`).

L'atelier conversationnel peut donc demander à ChatGPT de concevoir un plugin, recevoir un bloc `<AURA_PLUGIN_SPEC>`, le conserver, puis demander une autorisation avant activation.

Le SDK n'embarque pas un compilateur Android complet : compiler du Kotlin/Java arbitraire en APK est une opération de build distincte. Cette séparation protège le noyau d'Aura et permet de garder les extensions isolées.
