# Extension Agenda — V1

Aura peut préparer et exécuter des événements d’agenda à partir d’une intention comprise par le moteur IA.

Sur Android, V21 utilise le fournisseur CalendarContract et recherche en priorité un calendrier Google modifiable. Si le compte Google est synchronisé sur le téléphone, l’événement est ensuite synchronisé par Android avec Google Agenda.

L’accès nécessite les permissions Android READ_CALENDAR et WRITE_CALENDAR. Une permission manquante doit être demandée, jamais contournée.

Une création n’est confirmée à l’utilisateur qu’après retour positif du fournisseur calendrier.

Une future version pourra ajouter une connexion OAuth Google dédiée si l’on veut gérer des agendas qui ne sont pas synchronisés sur l’appareil.
