# Aura — liste des évolutions développables

## Prioritaires / prochaines briques
1. Orchestrateur multi-IA : sélectionner OpenAI/Claude/Gemini selon tâche, coût, latence et fiabilité.
2. Comparaison multi-modèles lorsque le gain attendu le justifie.
3. Conservation de la conclusion d’Aura distincte des réponses des fournisseurs.
4. Recherche sémantique complète du corpus multi-IA.
5. Rappels et notifications avec cycle complet et vérification.
6. Actions Android natives avec permissions granulaires et preuve d’exécution.
7. Interface déclarative auto-évolutive avec prévisualisation, validation, versioning et rollback.
8. Connecteurs/plugins dynamiques avec registre de capacités et permissions.
9. Synchronisation optionnelle et chiffrement de production.
10. Voix conversationnelle temps réel.
