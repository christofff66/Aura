# Aura V20 — Architecture d’orchestration

## Principe
Aura n’est pas un second cerveau qui concurrence ChatGPT. Aura est l’interface et l’orchestrateur local qui prépare un contexte personnalisé, le transmet au moteur IA choisi, puis conserve la trace de l’échange.

**Utilisateur → Aura → moteur IA (OpenAI/ChatGPT, passerelle éventuelle) → Aura → Utilisateur**

## Couches
1. **Interface conversationnelle** — écran principal de type ChatGPT, fils de conversation et saisie texte/voix.
2. **Aura Context Builder** — construit avant chaque appel un objet `AURA_CONTEXT_V1` contenant message utilisateur, historique récent, mémoires pertinentes, préférences, règles, capacités/plugins autorisés, date/heure et gouvernance.
3. **Mémoire & verbatim** — conservation locale de l’état complet dans `files/aura-memory/verbatim.json` (stockage privé Android via `getFilesDir()`). Les échanges gardent provenance, identifiants et lien vers le contexte utilisé.
4. **Préférences & gouvernance** — préférences de réponse, IA, habitudes, principes et règles de contrôle.
5. **Registre de capacités/plugins** — les capacités actives sont injectées au contexte. Un plugin généré par l’Atelier reste en attente jusqu’à autorisation explicite.
6. **AI Provider Gateway** — envoie le contexte au fournisseur configuré, avec passerelle Aura prioritaire si configurée, sinon appel OpenAI direct.
7. **Atelier / évolution** — permet de proposer des plugins isolés. Une modification du noyau nécessite une autorisation explicite.

## Traçabilité
Chaque message utilisateur crée un `context_snapshots[]` avec l’objet exact construit pour l’appel. La réponse IA référence ce snapshot via `source_id`. Cela permet de retrouver ce qu’Aura a présenté au moteur au moment de la réponse.

## Sécurité
La clé API OpenAI reste dans le stockage chiffré adossé à Android Keystore. Les plugins ne reçoivent pas directement les secrets et leur activation reste contrôlée.

## Limites V20
- L’Atelier est encore un registre/prototype de spécifications de plugins : il ne compile pas arbitrairement du code généré en module Android natif.
- La sélection de modèle doit utiliser un identifiant réellement disponible chez le fournisseur configuré. La valeur par défaut historique de l’interface est conservée mais peut devoir être changée dans Préférences.
- La recherche web et les outils externes restent dépendants du fournisseur/passerelle configuré ; Aura orchestre le contexte mais ne remplace pas ces services.
