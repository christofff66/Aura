# Aura V21 — interface ChatGPT + orchestrateur

## Principe
Toi → Aura → moteur IA → Aura → action vérifiée → mémoire.

La page d’accueil reste conversationnelle et minimaliste. Les fonctions secondaires vivent dans le menu : Agenda, tâches, mémoire, imports, plugins/évolutions et préférences IA.

## Contexte
Avant chaque appel, Aura construit un contexte comprenant le verbatim pertinent, mémoires, préférences, règles, capacités, corpus importé et candidats de récurrence. Le contrat distingue observation, compréhension et déduction.

## Actions
Le moteur IA peut proposer des actions structurées. Aura est responsable de l’exécution et de la vérification. Par défaut, les actions demandent confirmation.

Actions prévues : tâches, rappels Android, événements Google Agenda via le calendrier synchronisé du téléphone, mises à jour mémoire, propositions de plugins et propositions d’évolution.

## Plugins et évolution
Un plugin proposé reste inactif jusqu’à autorisation. Une modification du noyau reste soumise à autorisation explicite.

## Apprentissage
Aura conserve le verbatim. Elle peut détecter des récurrences comme des candidats, sans transformer automatiquement une répétition en diagnostic ou en vérité. Une hypothèse doit être vérifiée et peut être contredite.

## Imports
Les exports ChatGPT JSON/ZIP sont conservés avec leur provenance et servent à enrichir le corpus de contexte et les exemples de communication.

