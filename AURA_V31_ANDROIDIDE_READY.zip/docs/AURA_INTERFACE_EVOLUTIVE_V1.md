# Aura — interface évolutive V1

L'interface est traitée comme une couche déclarative au-dessus du noyau. Une capacité peut déclarer une surface, une carte, un raccourci ou un widget sans modifier les principes fondamentaux.

Aura peut **proposer** une évolution de l'interface à partir d'un besoin détecté. Une évolution validée est versionnée, journalisée et réversible. Aura ne peut pas s'auto-attribuer une modification importante de son interface.

Le manifeste `AURA_UI_MANIFEST_V1.json` sert de contrat minimal pour cette couche.
