# Aura — interface V15

Principe visuel : simple, calme, épuré. Pas de tableau de bord saturé.

## Entrée principale
- Conversation avec Aura.
- Quelques éléments réellement importants aujourd'hui.
- Une zone « Aura me propose » seulement lorsqu'une proposition existe.
- Accès permanent à « Capacités ».

## Capacités
Les capacités sont organisées par domaines d'intérêt. Chaque capacité affiche :
- ce qu'elle apporte concrètement ;
- son état : EN PLACE / ACTIVE / DISPONIBLE / À CONFIGURER / PROPOSÉE ;
- les accès nécessaires ;
- pourquoi Aura la propose éventuellement.

## Évolution
Une évolution affiche : besoin → solution → périmètre → changement prévu → validation → nouvelle version → vérification.
L'utilisateur n'a pas besoin de comprendre le code pour valider une évolution.
