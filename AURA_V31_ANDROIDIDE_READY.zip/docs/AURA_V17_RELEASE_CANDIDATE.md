# Aura V17 — Release Candidate d'usage

## Objectif
Passer d'un prototype d'architecture à une version Android concrètement utilisable sans prétendre que le noyau est déjà capable de s'auto-recompiler sur le téléphone.

## Capacités de départ
- conversation locale
- mémoire et journal local
- import/export d'exports IA
- voix Android
- synthèse vocale
- notifications Android
- rappels programmables depuis l'interface
- cycle de rappel et traçabilité
- catalogue de capacités
- onboarding réversible
- atelier de construction
- historique et rollback de versions déclaratives
- Gateway multi-fournisseurs
- Bootstrap SDK embarqué
- hub de connexions

## Auto-évolution
Aura suit : besoin → recherche → proposition → périmètre → autorisation → construction → tests → vérification → nouvelle version.

Une modification du noyau doit afficher explicitement son périmètre et obtenir une autorisation dédiée. Une autorisation d'interface ne donne pas automatiquement des droits supplémentaires.

## Connexions
Le hub distingue : intégré, configurable, extension prête, découverte sur besoin et action guidée. Aura ne doit pas intégrer arbitrairement des dizaines de connecteurs : elle doit identifier le besoin puis rechercher l'adaptateur/protocole approprié.

## APK
L'environnement de construction courant ne contient pas le SDK Android/Gradle nécessaire pour produire ici un binaire APK vérifié. Le projet reste toutefois prêt pour compilation Android et contient le workflow GitHub Actions de génération d'un APK debug.
