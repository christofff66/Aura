# Contrat AURA_CONTEXT_V1

Aura construit un contexte structuré avant chaque requête IA.

Champs principaux :
- `schema`
- `built_at`
- `source`
- `user_message`
- `recent_exchanges`
- `relevant_memories`
- `preferences`
- `rules`
- `capabilities`
- `current_time`
- `conversation_id`
- `conversation_mode`
- `plugin_factory`
- `governance`

Les champs ne remplacent jamais le verbatim : le verbatim reste la source primaire. Le contexte est une vue préparée pour l’appel IA.

### Gouvernance intégrée
- ne pas inventer le contexte manquant ;
- distinguer observation, compréhension et déduction ;
- activation d’un plugin uniquement après autorisation ;
- modification du noyau uniquement après autorisation explicite ;
- conserver la traçabilité du contexte utilisé.
