# Aura V18 — tableau de bord + préférences + agents

Base : Aura V17 reconstruite.

## Ce qui change
- Tableau de bord épuré inspiré du croquis validé : date + jour + heure en haut, navigation latérale et panneau de conversation Ora.
- Accès direct : Accueil, Planning, Tâches, Courses, Repas, Recettes rapides, Mémoire, Préférences.
- Conversation Ora visible en permanence sur grand écran et disponible en voix via Android.
- IA principale affichée par défaut comme **Maître Léon**, avec OpenAI et le modèle V17 `gpt-5.6-luna` comme valeur technique par défaut.
- Écran Préférences IA : nom, fournisseur, modèle, Gateway, style de réponse, proactivité, niveau de validation et recherche externe.
- Clé API OpenAI saisissable depuis Android et chiffrée via `SecretStore`.
- Préférences Shopping persistantes : rayon local, budgets, enseignes, marques, exclusions et critères de choix.
- Gestion des agents/plugins : ajout depuis le menu, sans donner automatiquement de nouvelles permissions au noyau.
- Agents de départ : Ora, Shopping, Bricolage.
- Le contexte envoyé au moteur IA contient les préférences et les agents actifs afin qu’ils puissent réellement orienter les réponses.

## Principes conservés
La V18 conserve le socle V17 : source distincte de l’interprétation, mémoire persistante, évolution contrôlée, autorisations explicites et architecture extensible.

## V18.1 — architecture modulaire et Linky
- Gestionnaire de modules séparé du noyau.
- Manifests de capacités et de connexions versionnés.
- Gestion générique des secrets de modules via Android Keystore.
- Module `energy.linky` prêt à être configuré après installation.
- Le token Linky/Conso API n'est pas exposé au JavaScript et n'est pas écrit en clair dans le code.
- Configuration/activation d'un module prévu sans recompilation de l'APK.

## V18.2 — Workspace modulaire
La V18.2 ajoute un bus d'événements noyau↔modules, un contrat UI évolutif, un espace d'accueil réorganisable et un catalogue de modules proposés. Le ZIP inclut un Gradle Wrapper/Bootstrap (Gradle 8.9) pour permettre à Android Studio de récupérer Gradle automatiquement.
