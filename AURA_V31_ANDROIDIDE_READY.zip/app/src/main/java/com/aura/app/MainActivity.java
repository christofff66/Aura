package com.aura.app;

import android.app.*;import android.os.*;import android.webkit.*;import android.view.*;import android.content.*;import android.net.Uri;import android.provider.Settings;import android.content.pm.PackageManager;import android.Manifest;import android.widget.*;import java.io.*;import java.net.*;import java.nio.charset.StandardCharsets;import java.util.*;
import java.util.zip.ZipEntry;import java.util.zip.ZipInputStream;import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends Activity {
  private static MainActivity instance;
    private final com.aura.sdk.AuraEventBus auraEventBus = new com.aura.sdk.AuraEventBus();
    public com.aura.sdk.AuraEventBus getAuraEventBus(){ return auraEventBus; }

  // RENSEIGNER ICI LA CLE API OpenAI (laisser tel quel si vous utilisez le Gateway)
  private static final String OPENAI_API_KEY = "METTRE ICI LA CLE API";
  private static final String OPENAI_MODEL = "gpt-5.6-luna";
  private static final String DEFAULT_AI_NAME = "Maître Léon";
  public static final int REQ_VOICE=4401, REQ_MIC=4403, REQ_IMPORT=4404, REQ_CALENDAR=4405;
  AuraServer server; WebView web; NativeAuraBridge bridge; SecretStore secrets;
  File importDir;
  File verbatimDir;
  File verbatimFile;
  private boolean hasKey(){
    if(secrets==null)return false;
    String k=secrets.get("openai_api_key");
    return k!=null && !k.trim().isEmpty() && !k.trim().equals("METTRE ICI LA CLE API");
  }

  @Override public void onCreate(Bundle b){super.onCreate(b); instance=this; web=new WebView(this); web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.getSettings().setAllowFileAccess(true);web.getSettings().setMediaPlaybackRequiresUserGesture(false);web.setWebViewClient(new WebViewClient());setContentView(web);
    secrets=new SecretStore(this); bridge=new NativeAuraBridge(this); web.addJavascriptInterface(bridge,"AuraNative"); importDir=new File(getCacheDir(),"aura-import"); importDir.mkdirs(); verbatimDir=new File(getFilesDir(),"aura-memory"); verbatimDir.mkdirs(); verbatimFile=new File(verbatimDir,"verbatim.json"); server=new AuraServer(this); server.start(); new Handler().postDelayed(()->web.loadUrl("http://127.0.0.1:8765/"),400); requestNotificationPermission();
  }
  synchronized void saveVerbatim(String json){
    if(json==null)return;
    try{File tmp=new File(verbatimDir,"verbatim.json.tmp");try(FileOutputStream o=new FileOutputStream(tmp)){o.write(json.getBytes(StandardCharsets.UTF_8));o.flush();}if(verbatimFile.exists()&&!verbatimFile.delete())return;if(!tmp.renameTo(verbatimFile)){try(FileInputStream in=new FileInputStream(tmp);FileOutputStream out=new FileOutputStream(verbatimFile)){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}tmp.delete();}}catch(Exception ignored){}
  }
  private byte[] readFileBytes(File f)throws IOException{try(InputStream in=new FileInputStream(f)){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toByteArray();}}
  synchronized String loadVerbatim(){
    try{if(verbatimFile!=null&&verbatimFile.exists())return new String(readFileBytes(verbatimFile),StandardCharsets.UTF_8);}catch(Exception ignored){}
    return "";
  }

  void askKey(){
    LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); int p=24; box.setPadding(p,p,p,p);
    EditText url=new EditText(this); url.setHint("URL du Aura Gateway (ex. http://192.168.1.10:8787)"); url.setText(getPreferences(0).getString("gateway_url",""));
    EditText api=new EditText(this); api.setHint("Clé API OpenAI (facultatif)"); api.setInputType(129);
    String existingApi=secrets.get("openai_api_key"); if(!existingApi.isEmpty()) api.setHint("Clé API OpenAI déjà enregistrée — saisir pour remplacer");
    EditText tok=new EditText(this); tok.setHint("Jeton du Gateway (facultatif)"); tok.setInputType(129);
    Spinner provider=new Spinner(this); String[] ps={"openai","anthropic","gemini"}; provider.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,ps)); String pv=getPreferences(0).getString("provider","openai"); for(int i=0;i<ps.length;i++)if(ps[i].equals(pv))provider.setSelection(i);
    EditText model=new EditText(this); model.setHint("Modèle (facultatif)"); model.setText(getPreferences(0).getString("model",OPENAI_MODEL));
    EditText name=new EditText(this); name.setHint("Nom de l’IA"); name.setText(getPreferences(0).getString("ai_name",DEFAULT_AI_NAME));
    box.addView(name);box.addView(url);box.addView(api);box.addView(tok);box.addView(provider);box.addView(model);
    new AlertDialog.Builder(this).setTitle("Préférences IA — "+DEFAULT_AI_NAME).setMessage("La clé API est chiffrée dans le stockage sécurisé Android. Le Gateway reste le mode recommandé pour éviter d’exposer les secrets dans l’APK.").setView(box).setNegativeButton("Plus tard",null).setPositiveButton("Enregistrer",(d,w)->{
      getPreferences(0).edit().putString("ai_name",name.getText().toString().trim().isEmpty()?DEFAULT_AI_NAME:name.getText().toString().trim()).putString("gateway_url",url.getText().toString().trim()).putString("provider",ps[provider.getSelectedItemPosition()]).putString("model",model.getText().toString().trim()).apply();
      String k=api.getText().toString().trim(); if(!k.isEmpty()) secrets.put("openai_api_key",k);
      String t=tok.getText().toString().trim(); if(!t.isEmpty()) secrets.put("gateway_token",t); else if(!url.getText().toString().trim().isEmpty()) secrets.remove("gateway_token"); toast("Préférences IA enregistrées.");
    }).show();
  }
  void requestNotificationPermission(){ if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},4402); }
  void startAuraService(){ try{Intent i=new Intent(this,AuraForegroundService.class); if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);}catch(Exception ignored){} }
  void stopAuraService(){ try{stopService(new Intent(this,AuraForegroundService.class));}catch(Exception ignored){} }
  void saveAiConfig(String name,String provider,String model,String gateway){getPreferences(0).edit().putString("ai_name",(name==null||name.trim().isEmpty())?DEFAULT_AI_NAME:name.trim()).putString("provider",provider==null?"openai":provider.trim()).putString("model",(model==null||model.trim().isEmpty())?OPENAI_MODEL:model.trim()).putString("gateway_url",gateway==null?"":gateway.trim()).apply();}
  void saveModuleSecret(String moduleId,String secretName,String value){
    if(moduleId==null||secretName==null||value==null)return;
    String key="module."+moduleId+"."+secretName;
    if(value.trim().isEmpty()) secrets.remove(key); else secrets.put(key,value.trim());
  }
  boolean moduleSecretConfigured(String moduleId,String secretName){return moduleId!=null&&secretName!=null&&!secrets.get("module."+moduleId+"."+secretName).isEmpty();}
  void setModuleEnabled(String moduleId,boolean enabled){if(moduleId==null)return;getPreferences(0).edit().putBoolean("module."+moduleId+".enabled",enabled).apply();}
  boolean isModuleEnabled(String moduleId){return moduleId!=null&&getPreferences(0).getBoolean("module."+moduleId+".enabled",false);}
  void configureModule(String moduleId,String title,String secretName,String secretHint){
    LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);int p=24;box.setPadding(p,p,p,p);
    TextView info=new TextView(this);info.setText("Le module reste séparé du noyau. Le secret est chiffré dans Android et n'est jamais renvoyé à l'interface Web. Tu peux le renseigner maintenant ou plus tard.");
    EditText secret=new EditText(this);secret.setHint(secretHint==null?"Token / clé API":secretHint);secret.setInputType(129);
    if(moduleSecretConfigured(moduleId,secretName))secret.setHint("Identifiant déjà enregistré — saisir pour remplacer");
    box.addView(info);box.addView(secret);
    new AlertDialog.Builder(this).setTitle(title).setView(box).setNegativeButton("Plus tard",null).setPositiveButton("Enregistrer",(d,w)->{saveModuleSecret(moduleId,secretName,secret.getText().toString());setModuleEnabled(moduleId,true);toast(title+" configuré.");}).show();
  }
  void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}
  public static void receiveChatGPTReply(String text){
    MainActivity a=instance; if(a==null||a.web==null)return;
    a.runOnUiThread(() -> a.web.evaluateJavascript("window.auraChatGPTReply && window.auraChatGPTReply("+a.jsQuote(text)+");",null));
  }
  boolean isChatGPTBridgeEnabled(){ return ChatGPTAccessibilityService.getInstance()!=null; }
  void startChatGPTNativeVoice(){
    ChatGPTAccessibilityService svc=ChatGPTAccessibilityService.getInstance();
    if(svc==null){
      openAccessibilitySettings();
      toast("Active d’abord le pont d’accessibilité Aura, puis relance la voix.");
      try{ Intent launch=getPackageManager().getLaunchIntentForPackage("com.openai.chatgpt"); if(launch!=null) startActivity(launch); }catch(Exception ignored){}
      return;
    }
    svc.openNativeVoice();
  }

  void sendToChatGPT(String text){
    if(!isChatGPTBridgeEnabled()){ openAccessibilitySettings(); return; }
    ChatGPTAccessibilityService.getInstance().sendToCurrentConversation(text);
  }
  void openAccessibilitySettings(){ try{startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));}catch(Exception e){toast("Ouvre Paramètres Android → Accessibilité pour activer le Pont ChatGPT.");} }
  @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);
    if(req==REQ_IMPORT&&result==RESULT_OK&&data!=null&&data.getData()!=null){handleImportUri(data.getData());}
  }
  void pickImport(){try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/json","application/zip","application/x-zip-compressed","text/html","text/plain"});startActivityForResult(i,REQ_IMPORT);}catch(Exception e){toast("Impossible d'ouvrir le sélecteur de fichiers.");}}
  void handleImportUri(Uri uri){new Thread(()->{try{for(File f:Objects.requireNonNull(importDir.listFiles())) if(f.isFile()) f.delete(); String name=String.valueOf(uri.getLastPathSegment()); if(name.contains("/")) name=name.substring(name.lastIndexOf('/')+1); if(name.isEmpty()) name="export"; String lower=name.toLowerCase(Locale.ROOT); if(lower.endsWith(".zip")){try(InputStream in=getContentResolver().openInputStream(uri);ZipInputStream z=new ZipInputStream(in)){ZipEntry e;int count=0;while((e=z.getNextEntry())!=null&&count<500){if(e.isDirectory()){z.closeEntry();continue;}String safe=e.getName().replace('\\','/');if(safe.contains("../")||safe.startsWith("/")){z.closeEntry();continue;}String base=safe.substring(safe.lastIndexOf('/')+1);if(base.isEmpty()){z.closeEntry();continue;}String ext=base.toLowerCase(Locale.ROOT);if(!(ext.endsWith(".json")||ext.endsWith(".html")||ext.endsWith(".txt"))){z.closeEntry();continue;}File out=new File(importDir,count+"_"+base);try(OutputStream o=new FileOutputStream(out)){byte[] b=new byte[8192];int n;long total=0;while((n=z.read(b))>0&&total<30_000_000L){o.write(b,0,n);total+=n;}}count++;z.closeEntry();}}}else{File out=new File(importDir,"0_"+name);try(InputStream in=getContentResolver().openInputStream(uri);OutputStream o=new FileOutputStream(out)){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)o.write(b,0,n);}} runOnUiThread(()->{if(web!=null)web.evaluateJavascript("window.auraImportReady && window.auraImportReady();",null);toast("Export prêt à être analysé par Aura.");});}catch(Exception e){toast("Import impossible : "+e.getMessage());}}).start();}

  String jsQuote(String s){return org.json.JSONObject.quote(s==null?"":s);}
  @Override protected void onDestroy(){if(bridge!=null)bridge.shutdown(); if(server!=null)server.shutdown();super.onDestroy();}

  class AuraServer extends Thread {
    Context c; volatile boolean run=true; ServerSocket ss; String root="public";
    AuraServer(Context c){this.c=c;}
    public void run(){try{ss=new ServerSocket(8765,20,InetAddress.getByName("127.0.0.1"));while(run){final Socket s=ss.accept();new Thread(()->handle(s)).start();}}catch(Exception ignored){}}
    String readHttpLine(InputStream in)throws IOException{ByteArrayOutputStream out=new ByteArrayOutputStream();int prev=-1,c;while((c=in.read())!=-1){if(prev=='\r'&&c=='\n'){out.write('\r');break;}out.write(c);prev=c;if(out.size()>8192)throw new IOException("HTTP header too large");}if(c==-1&&out.size()==0)return null;byte[] b=out.toByteArray();int n=b.length;while(n>0&&(b[n-1]=='\r'||b[n-1]=='\n'))n--;return new String(b,0,n,StandardCharsets.ISO_8859_1);}
    byte[] readExactly(InputStream in,int len)throws IOException{if(len<=0)return new byte[0];ByteArrayOutputStream out=new ByteArrayOutputStream(len);byte[] b=new byte[8192];int left=len;while(left>0){int n=in.read(b,0,Math.min(b.length,left));if(n<0)throw new EOFException("Request body truncated");out.write(b,0,n);left-=n;}return out.toByteArray();}
    void handle(Socket s){try{InputStream rawIn=s.getInputStream();String line=readHttpLine(rawIn);if(line==null){s.close();return;}String[] q=line.split(" ",3);String method=q[0], path=q.length>1?q[1]:"/";int len=0;String h;while((h=readHttpLine(rawIn))!=null&&!h.isEmpty()){if(h.toLowerCase(Locale.ROOT).startsWith("content-length:"))len=Integer.parseInt(h.substring(h.indexOf(':')+1).trim());}byte[] bodyBytes=readExactly(rawIn,len);String body=new String(bodyBytes,StandardCharsets.UTF_8);
      if(path.equals("/api/import/list")){send(s,importList(),"application/json");}
      else if(path.startsWith("/api/import/file?name=") ){String raw=path.substring("/api/import/file?name=".length());String name=java.net.URLDecoder.decode(raw,"UTF-8");File f=new File(importDir,name);if(!f.getCanonicalPath().startsWith(importDir.getCanonicalPath()+File.separator)){send(s,"{\"error\":\"forbidden\"}","application/json");}else if(f.exists()){sendBytes(s,readFileBytes(f),mime(f.getName()));}else send(s,"{\"error\":\"not_found\"}","application/json");}
      else if(path.equals("/api/capabilities")){send(s,asset("data/AURA_CAPABILITY_REGISTRY_V2.json"),"application/json");}
      else if(path.equals("/api/connections")){send(s,asset("data/AURA_CONNECTION_HUB_V1.json"),"application/json");}
      else if(path.equals("/api/status")){send(s,"{\"ok\":true,\"ai_configured\":"+hasKey()+",\"model\":"+quote(getPreferences(0).getString("model", ""))+",\"provider\":"+quote(getPreferences(0).getString("provider", "gateway"))+",\"master\":\"V1.1\",\"connection\":\"gateway-preferred\"}","application/json");}
      else if(path.equals("/api/aura")&&method.equals("POST")){send(s,askAI(body),"application/json");}
      else if(path.equals("/api/bootstrap")){String b=asset("data/aura-bootstrap.json");send(s,"{\"bootstrap\":"+b+",\"master_version\":\"V1.1\"}","application/json");}
      else if(path.equals("/api/memory/consolidate")){send(s,"{\"mode\":\"local\",\"consolidated\":[],\"message\":\"Consolidation disponible après connexion IA.\"}","application/json");}
      else {String p=path.equals("/")?"public/index.html":("public"+path);String data=asset(p);String ct=p.endsWith(".js")?"text/javascript":p.endsWith(".css")?"text/css":p.endsWith(".webmanifest")?"application/manifest+json":"text/html";send(s,data,ct);}
      s.close();}catch(Exception e){try{send(s,"{\"error\":\""+esc(e.toString())+"\"}","application/json");s.close();}catch(Exception ignored){}}}
    String importList(){try{StringBuilder b=new StringBuilder("[");File[] fs=importDir.listFiles();if(fs!=null){boolean first=true;for(File f:fs){if(!f.isFile())continue;if(!first)b.append(',');first=false;b.append("{\"name\":").append(quote(f.getName())).append(",\"size\":").append(f.length()).append('}');}}return b.append(']').toString();}catch(Exception e){return "[]";}}
    String mime(String n){String l=n.toLowerCase(Locale.ROOT);if(l.endsWith(".json"))return "application/json";if(l.endsWith(".html"))return "text/html";return "text/plain";}
    byte[] readAll(InputStream in)throws IOException{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toByteArray();}
    byte[] readFileBytes(File f)throws IOException{try(InputStream in=new FileInputStream(f)){return readAll(in);}}
String askAI(String body){
      String user=extract(body,"user_message");
      String input=extractJsonValue(body,"context");
      if(input.isEmpty()) input=user;
      String provider=getPreferences(0).getString("provider","openai").trim();
      String model=getPreferences(0).getString("model",OPENAI_MODEL).trim();
      if(model.isEmpty()) model=OPENAI_MODEL;
      String contract="Tu es le moteur d’intelligence générale appelé par Aura. Aura est l’orchestrateur local et te fournit son contexte. Réponds directement à l’utilisateur en français. Si une action réelle est pertinente, retourne un JSON avec answer, action_candidates, memory_candidates et recurrence_candidates. Ne prétends jamais qu’une action a été réalisée : Aura doit l’exécuter puis la vérifier. Distingue observation, compréhension et déduction. N’invente jamais une information absente du contexte.";
      String prompt=contract+"\n\nCONTEXTE AURA:\n"+input+"\n\nMESSAGE UTILISATEUR:\n"+user;

      String gateway=getPreferences(0).getString("gateway_url","").trim();
      if(!gateway.isEmpty()) {
        try{
          URL u=new URL(gateway.replaceAll("/$","")+"/v1/aura");
          HttpURLConnection x=(HttpURLConnection)u.openConnection();
          x.setRequestMethod("POST");x.setRequestProperty("Content-Type","application/json");x.setRequestProperty("Accept","application/json");
          String t=secrets.get("gateway_token");if(!t.isEmpty())x.setRequestProperty("Authorization","Bearer "+t);
          x.setDoOutput(true);x.setConnectTimeout(8000);x.setReadTimeout(60000);
          String json="{\"provider\":"+quote(provider)+",\"model\":"+quote(model)+",\"input\":"+quote(prompt)+"}";
          try(OutputStream os=x.getOutputStream()){os.write(json.getBytes(StandardCharsets.UTF_8));}
          int rc=x.getResponseCode();InputStream is=rc<400?x.getInputStream():x.getErrorStream();String out=is==null?"":new String(readAll(is),StandardCharsets.UTF_8);
          if(rc>=400)throw new IOException("Gateway HTTP "+rc+": "+out);
          return normalizeGateway(out);
        }catch(Exception gatewayError){
          // Fallback automatique vers OpenAI direct : une passerelle locale indisponible ne doit jamais rendre Aura muette.
        }
      }

      String key=OPENAI_API_KEY;
      if(key.equals("METTRE ICI LA CLE API")||key.isEmpty())key=secrets.get("openai_api_key");
      if(key.isEmpty())key=getPreferences(0).getString("api_key","");
      if(key.isEmpty())return errorJson("IA non configurée : ajoute ta clé API OpenAI dans Préférences → Connexion IA.");
      try{
        URL u=new URL("https://api.openai.com/v1/responses");
        HttpURLConnection x=(HttpURLConnection)u.openConnection();x.setRequestMethod("POST");x.setRequestProperty("Authorization","Bearer "+key);x.setRequestProperty("Content-Type","application/json");x.setRequestProperty("Accept","application/json");x.setDoOutput(true);x.setConnectTimeout(15000);x.setReadTimeout(90000);
        String json="{\"model\":"+quote(model)+",\"input\":"+quote(prompt)+"}";
        try(OutputStream os=x.getOutputStream()){os.write(json.getBytes(StandardCharsets.UTF_8));}
        int rc=x.getResponseCode();InputStream is=rc<400?x.getInputStream():x.getErrorStream();String out=is==null?"":new String(readAll(is),StandardCharsets.UTF_8);
        if(rc>=400){String detail=out;try{org.json.JSONObject er=new org.json.JSONObject(out);detail=er.optString("error",out);if(er.opt("error") instanceof org.json.JSONObject)detail=((org.json.JSONObject)er.opt("error")).optString("message",out);}catch(Exception ignored){}throw new IOException("OpenAI HTTP "+rc+": "+detail);}
        String text=extractOutput(out);if(text==null||text.trim().isEmpty())throw new IOException("OpenAI a répondu sans texte.");
        return normalize(text);
      }catch(Exception e){return errorJson("Je n’ai pas reçu de réponse de l’IA. "+e.getMessage());}
    }
    String errorJson(String message){return "{\"mode\":\"error\",\"answer\":"+quote(message)+",\"question\":{\"exists\":false,\"formulation\":\"\",\"blocking\":false,\"reason\":\"\"},\"memory_candidates\":[],\"action_candidates\":[],\"recurrence_candidates\":[]}";}
    String normalizeGateway(String t){ try{int a=t.indexOf('{'),b=t.lastIndexOf('}');if(a>=0&&b>a){String j=t.substring(a,b+1);org.json.JSONObject o=new org.json.JSONObject(j);String text=o.optString("text","");return normalize(text);} }catch(Exception ignored){} return normalize(t); }
    String extractOutput(String j){
      try { org.json.JSONObject o=new org.json.JSONObject(j); String text=o.optString("output_text",""); if(!text.isEmpty()) return text;
        org.json.JSONArray out=o.optJSONArray("output"); if(out!=null){ StringBuilder b=new StringBuilder(); for(int i=0;i<out.length();i++){ org.json.JSONObject item=out.optJSONObject(i); if(item==null) continue; org.json.JSONArray content=item.optJSONArray("content"); if(content==null) continue; for(int k=0;k<content.length();k++){ org.json.JSONObject c=content.optJSONObject(k); if(c!=null){ String tx=c.optString("text",""); if(!tx.isEmpty()) b.append(tx); } } } if(b.length()>0)return b.toString(); }
      } catch(Exception ignored){} return j;
    }
    String normalize(String t){try{int a=t.indexOf('{'),b=t.lastIndexOf('}');if(a>=0&&b>a)return t.substring(a,b+1);}catch(Exception ignored){}return "{\"mode\":\"ai\",\"answer\":"+quote(t)+",\"question\":{\"exists\":false,\"formulation\":\"\",\"blocking\":false,\"reason\":\"\"},\"memory_candidates\":[],\"action_candidates\":[],\"reasoning_summary\":[],\"needs_user_input\":false}";}
    String extract(String j,String k){try{return new org.json.JSONObject(j).optString(k,"");}catch(Exception e){return "";}}
    String extractJsonValue(String j,String k){try{org.json.JSONObject o=new org.json.JSONObject(j);Object v=o.opt(k);return v==null?"":(v instanceof org.json.JSONObject||v instanceof org.json.JSONArray?v.toString():String.valueOf(v));}catch(Exception e){return "";}}
    String quote(String s){return "\""+esc(s)+"\"";}String esc(String s){return String.valueOf(s).replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","");}
    String asset(String p)throws Exception{InputStream in=c.getAssets().open(p);ByteArrayOutputStream o=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))>0)o.write(b,0,n);return o.toString("UTF-8");}
    void sendBytes(Socket s,byte[] b,String ct)throws Exception{OutputStream o=s.getOutputStream();String h="HTTP/1.1 200 OK\r\nContent-Type: "+ct+"; charset=utf-8\r\nContent-Length: "+b.length+"\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n";o.write(h.getBytes(StandardCharsets.UTF_8));o.write(b);o.flush();}
    void send(Socket s,String body,String ct)throws Exception{byte[] b=body.getBytes(StandardCharsets.UTF_8);OutputStream o=s.getOutputStream();String h="HTTP/1.1 200 OK\r\nContent-Type: "+ct+"; charset=utf-8\r\nContent-Length: "+b.length+"\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n";o.write(h.getBytes(StandardCharsets.UTF_8));o.write(b);o.flush();}
    void shutdown(){run=false;try{if(ss!=null)ss.close();}catch(Exception ignored){}}
  }
}
