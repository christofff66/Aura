package com.aura.app;

import android.app.*;import android.content.*;import android.os.*;

public class AuraForegroundService extends Service {
  static final String CHANNEL="aura_presence";
  @Override public void onCreate(){super.onCreate();
    NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
    if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Aura active",NotificationManager.IMPORTANCE_LOW));
    Intent open=new Intent(this,MainActivity.class); PendingIntent pi=PendingIntent.getActivity(this,78,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
    b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Aura est active").setContentText("Le service de rappels Aura est actif.").setOngoing(true).setContentIntent(pi);
    startForeground(1001,b.build());
  }
  @Override public int onStartCommand(Intent i,int flags,int id){return START_STICKY;}
  @Override public android.os.IBinder onBind(Intent i){return null;}
}
