package com.aura.app;

import android.accessibilityservice.AccessibilityService;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.*;

/**
 * Optional, user-enabled bridge to the official ChatGPT Android app.
 * It does not read credentials or API keys. It only automates the visible
 * conversation that the user has explicitly opened in ChatGPT.
 */
public class ChatGPTAccessibilityService extends AccessibilityService {
  public static final String PACKAGE = "com.openai.chatgpt";
  private static ChatGPTAccessibilityService instance;
  private final Handler handler = new Handler(Looper.getMainLooper());
  private String pendingMessage = "";
  private String baseline = "";
  private long requestStarted;
  private int stableCount = 0;
  private String lastCandidate = "";
  private boolean sending = false;
  private ChatGPTBridgeStore store;
  private String lastSnapshot = "";

  public static ChatGPTAccessibilityService getInstance(){ return instance; }

  @Override public void onServiceConnected(){ super.onServiceConnected(); instance=this; store=new ChatGPTBridgeStore(this); }
  @Override public void onAccessibilityEvent(AccessibilityEvent event){
    if(event.getPackageName()==null || !PACKAGE.equals(event.getPackageName().toString())) return;
    captureVisibleConversation();
    if(sending) inspectForReply();
  }
  @Override public void onInterrupt(){ sending=false; }
  @Override public void onDestroy(){ if(instance==this) instance=null; sending=false; super.onDestroy(); }


  /** Passive capture: preserve the visible ChatGPT conversation as immutable source material. */
  private void captureVisibleConversation(){
    AccessibilityNodeInfo root=getRootInActiveWindow();
    if(root==null || store==null) return;
    String snapshot=snapshot(root);
    if(snapshot.isEmpty() || snapshot.equals(lastSnapshot)) return;
    lastSnapshot=snapshot;
    store.appendSnapshot(snapshot);
  }

  /** Opens ChatGPT and clicks its visible native Voice button. No Android/Google speech API is used. */
  public void openNativeVoice(){
    sending=false;
    try{
      Intent launch=getPackageManager().getLaunchIntentForPackage(PACKAGE);
      if(launch!=null){ launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(launch); }
    }catch(Exception ignored){}
    handler.postDelayed(this::clickNativeVoice,1200);
  }

  private void clickNativeVoice(){
    AccessibilityNodeInfo root=getRootInActiveWindow();
    AccessibilityNodeInfo voice=findVoice(root);
    if(voice!=null){ try{ if(voice.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return; }catch(Exception ignored){} }
    handler.postDelayed(this::clickNativeVoice,800);
  }

  private AccessibilityNodeInfo findVoice(AccessibilityNodeInfo n){
    if(n==null)return null;
    String t=String.valueOf(n.getText());
    String d=String.valueOf(n.getContentDescription());
    String all=(t+" "+d).toLowerCase(Locale.ROOT);
    boolean voiceLabel=all.contains("voice")||all.contains("vocal")||all.contains("voix")||all.contains("parler")||all.contains("speak")||all.contains("dictée")||all.contains("dictation");
    if(n.isVisibleToUser() && n.isClickable() && voiceLabel) return n;
    for(int i=0;i<n.getChildCount();i++){ AccessibilityNodeInfo r=findVoice(n.getChild(i)); if(r!=null)return r; }
    return null;
  }

  public void sendToCurrentConversation(String text){
    if(text==null || text.trim().isEmpty()) return;
    pendingMessage=text.trim();
    AccessibilityNodeInfo root=getRootInActiveWindow();
    baseline=snapshot(root);
    sending=true; stableCount=0; lastCandidate=""; requestStarted=System.currentTimeMillis();
    try{
      Intent launch=getPackageManager().getLaunchIntentForPackage(PACKAGE);
      if(launch!=null){ launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(launch); }
    }catch(Exception ignored){}
    handler.postDelayed(this::injectMessage,900);
    handler.postDelayed(this::timeout,65000);
  }

  private void injectMessage(){
    if(!sending) return;
    AccessibilityNodeInfo root=getRootInActiveWindow();
    AccessibilityNodeInfo input=findEditable(root);
    if(input==null){ handler.postDelayed(this::injectMessage,800); return; }
    try{
      android.os.Bundle args=new android.os.Bundle();
      args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,pendingMessage);
      input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,args);
      handler.postDelayed(this::clickSend,180);
    }catch(Exception e){ fail("Je n’ai pas pu écrire dans la conversation ChatGPT."); }
  }

  private void clickSend(){
    if(!sending) return;
    AccessibilityNodeInfo root=getRootInActiveWindow();
    AccessibilityNodeInfo send=findSend(root);
    if(send!=null){ try{send.performAction(AccessibilityNodeInfo.ACTION_CLICK);}catch(Exception ignored){} }
    handler.postDelayed(this::inspectForReply,900);
  }

  private void inspectForReply(){
    if(!sending) return;
    AccessibilityNodeInfo root=getRootInActiveWindow();
    if(root==null) return;
    String candidate=findLatestAssistantLikeText(root);
    if(candidate.isEmpty() || candidate.equals(pendingMessage)) return;
    if(candidate.equals(lastCandidate)) stableCount++; else { lastCandidate=candidate; stableCount=0; }
    // Wait for a stable visible answer so streaming output is not returned too early.
    if(stableCount>=2 && candidate.length()>8 && System.currentTimeMillis()-requestStarted>1500){
      complete(candidate);
    } else if(System.currentTimeMillis()-requestStarted<60000){
      handler.postDelayed(this::inspectForReply,1000);
    }
  }

  private void timeout(){ if(sending && System.currentTimeMillis()-requestStarted>=60000) fail("Je n’ai pas réussi à récupérer la réponse de ChatGPT dans le délai prévu."); }

  private void complete(String text){
    if(!sending)return; sending=false;
    final String answer=text.trim();
    MainActivity.receiveChatGPTReply(answer);
  }
  private void fail(String message){ if(!sending)return; sending=false; MainActivity.receiveChatGPTReply("[AURA_BRIDGE_ERROR] "+message); }

  private AccessibilityNodeInfo findEditable(AccessibilityNodeInfo n){
    if(n==null)return null;
    CharSequence cls=n.getClassName();
    if(n.isVisibleToUser() && n.isEditable() && cls!=null && cls.toString().contains("EditText")) return n;
    for(int i=0;i<n.getChildCount();i++){ AccessibilityNodeInfo r=findEditable(n.getChild(i)); if(r!=null)return r; }
    return null;
  }

  private AccessibilityNodeInfo findSend(AccessibilityNodeInfo n){
    if(n==null)return null;
    String t=String.valueOf(n.getText()); String d=String.valueOf(n.getContentDescription());
    String all=(t+" "+d).toLowerCase(Locale.ROOT);
    if(n.isVisibleToUser() && n.isClickable() && (all.contains("send")||all.contains("envoyer")||all.equals("↗")||all.equals("➤"))) return n;
    for(int i=0;i<n.getChildCount();i++){ AccessibilityNodeInfo r=findSend(n.getChild(i)); if(r!=null)return r; }
    return null;
  }

  private String findLatestAssistantLikeText(AccessibilityNodeInfo root){
    ArrayList<String> texts=new ArrayList<>(); collectTexts(root,texts);
    String best="";
    for(String s:texts){
      String t=clean(s);
      if(t.length()<9 || t.equals(clean(pendingMessage))) continue;
      if(isUiNoise(t)) continue;
      // The newest long visible text is normally the streamed assistant message.
      best=t;
    }
    return best;
  }
  private void collectTexts(AccessibilityNodeInfo n,List<String> out){
    if(n==null)return;
    if(n.isVisibleToUser()){
      CharSequence t=n.getText(); if(t!=null&&!TextUtils.isEmpty(t.toString().trim())) out.add(t.toString());
    }
    for(int i=0;i<n.getChildCount();i++) collectTexts(n.getChild(i),out);
  }
  private String snapshot(AccessibilityNodeInfo n){ArrayList<String> a=new ArrayList<>();collectTexts(n,a);return a.toString();}
  private String clean(String s){return s.replaceAll("\\s+"," ").trim();}
  private boolean isUiNoise(String s){
    String x=s.toLowerCase(Locale.ROOT);
    return x.equals("copier")||x.equals("copy")||x.equals("regenerate")||x.equals("regénérer")||x.equals("partager")||x.equals("share")||x.equals("like")||x.equals("dislike")||x.equals("modifier")||x.equals("edit");
  }
}
