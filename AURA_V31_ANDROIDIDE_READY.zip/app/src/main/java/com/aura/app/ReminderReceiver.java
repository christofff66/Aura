package com.aura.app;

import android.app.*;import android.content.*;import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
  public static final String ACTION_REMINDER="com.aura.app.REMINDER";
  static final String CHANNEL="aura_reminders";
  @Override public void onReceive(Context c,Intent i){
    NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
    if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Rappels Aura",NotificationManager.IMPORTANCE_HIGH));
    Intent open=new Intent(c,MainActivity.class); open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
    PendingIntent pi=PendingIntent.getActivity(c,77,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    String title=i.getStringExtra("title"); String msg=i.getStringExtra("message");
    Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CHANNEL):new Notification.Builder(c);
    b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title==null?"Aura":title).setContentText(msg==null?"Rappel Aura":msg).setAutoCancel(true).setContentIntent(pi);
    nm.notify((int)(System.currentTimeMillis()&0x7fffffff),b.build());
  }
}
