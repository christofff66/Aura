package com.aura.app;

import android.content.Context;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.*;

/** Immutable local source log for the ChatGPT accessibility bridge. */
public final class ChatGPTBridgeStore {
  private final File file;
  private final Object lock = new Object();
  private String lastHash = "";

  public ChatGPTBridgeStore(Context context) {
    File dir = new File(context.getFilesDir(), "aura-memory");
    if (!dir.exists()) dir.mkdirs();
    file = new File(dir, "chatgpt-bridge-verbatim.jsonl");
  }

  public void appendSnapshot(String snapshot) {
    if (snapshot == null) return;
    String text = snapshot.trim();
    if (text.isEmpty()) return;
    String hash = sha256(text);
    synchronized (lock) {
      if (hash.equals(lastHash)) return;
      lastHash = hash;
      String ts = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.ROOT).format(new Date());
      String line = "{\"source\":\"chatgpt_accessibility\",\"captured_at\":\"" + esc(ts) + "\",\"sha256\":\"" + hash + "\",\"kind\":\"ui_snapshot\",\"verbatim\":" + quote(text) + "}\n";
      try (FileOutputStream out = new FileOutputStream(file, true)) {
        out.write(line.getBytes(StandardCharsets.UTF_8));
        out.flush();
      } catch (IOException ignored) {}
    }
  }

  public File getFile() { return file; }

  private static String sha256(String s) {
    try {
      MessageDigest md = MessageDigest.getInstance("SHA-256");
      byte[] b = md.digest(s.getBytes(StandardCharsets.UTF_8));
      StringBuilder out = new StringBuilder();
      for (byte x : b) out.append(String.format(Locale.ROOT, "%02x", x));
      return out.toString();
    } catch (Exception e) { return ""; }
  }
  private static String quote(String s) { return "\"" + esc(s) + "\""; }
  private static String esc(String s) { return String.valueOf(s).replace("\\", "\\\\").replace("\"", "\\\"").replace("\r", "\\r").replace("\n", "\\n"); }
}
