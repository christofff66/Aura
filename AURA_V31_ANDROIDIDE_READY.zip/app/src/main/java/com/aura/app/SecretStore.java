package com.aura.app;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

final class SecretStore {
  private static final String KS="AndroidKeyStore", ALIAS="AuraSecrets", PREF="aura_secure";
  private final Context c;
  SecretStore(Context c){this.c=c.getApplicationContext();}
  private SecretKey key() throws Exception {
    KeyStore ks=KeyStore.getInstance(KS); ks.load(null);
    if(!ks.containsAlias(ALIAS)){KeyGenerator g=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,KS);g.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());g.generateKey();}
    return ((KeyStore)ks).getKey(ALIAS,null) instanceof SecretKey ? (SecretKey)ks.getKey(ALIAS,null) : null;
  }
  void put(String name,String value){try{SecretKey k=key();Cipher x=Cipher.getInstance("AES/GCM/NoPadding");x.init(Cipher.ENCRYPT_MODE,k);byte[] ct=x.doFinal(value.getBytes(StandardCharsets.UTF_8));c.getSharedPreferences(PREF,0).edit().putString(name,Base64.encodeToString(x.getIV(),Base64.NO_WRAP)+":"+Base64.encodeToString(ct,Base64.NO_WRAP)).apply();}catch(Exception ignored){}}
  String get(String name){try{String v=c.getSharedPreferences(PREF,0).getString(name,null);if(v==null)return "";String[] p=v.split(":",2);Cipher x=Cipher.getInstance("AES/GCM/NoPadding");x.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(p[0],Base64.NO_WRAP)));return new String(x.doFinal(Base64.decode(p[1],Base64.NO_WRAP)),StandardCharsets.UTF_8);}catch(Exception e){return "";}}
  void remove(String name){c.getSharedPreferences(PREF,0).edit().remove(name).apply();}
}
