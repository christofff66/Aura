package com.aura.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.os.Build;

/** Restores reminders explicitly persisted by Aura after a reboot/update. */
public class BootReceiver extends BroadcastReceiver {
  @Override public void onReceive(Context context, Intent intent) {
    SharedPreferences p=context.getSharedPreferences("aura_reminders",Context.MODE_PRIVATE);
    String all=p.getString("items","");
    if(all.isEmpty()) return;
    AlarmManager am=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
    for(String item: all.split("\\n")) {
      String[] x=item.split("\\|",-1);
      if(x.length<4) continue;
      try {
        long at=Long.parseLong(x[0]); if(at<=System.currentTimeMillis()) continue;
        Intent i=new Intent(context,ReminderReceiver.class).setAction(ReminderReceiver.ACTION_REMINDER)
          .putExtra("title",x[1]).putExtra("message",x[2]);
        int id=Integer.parseInt(x[3]);
        PendingIntent pi=PendingIntent.getBroadcast(context,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        if(am!=null) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);
      } catch(Exception ignored){}
    }
  }
}
