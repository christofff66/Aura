package com.aura.app;

import android.app.*;
import android.content.ContentValues;
import android.content.*;
import android.os.Build;
import android.provider.Settings;import android.content.pm.PackageManager;import android.Manifest;
import android.net.Uri;
import android.provider.CalendarContract;
import android.webkit.JavascriptInterface;
import java.util.*;

public class NativeAuraBridge {
  private final MainActivity activity;
  NativeAuraBridge(MainActivity activity){ this.activity=activity; }

  /** Opens the official ChatGPT app and asks the accessibility bridge to activate its native Voice button. */
  @JavascriptInterface public void startVoice(){ activity.startChatGPTNativeVoice(); }

  @JavascriptInterface public boolean scheduleReminder(long atMillis,String title,String message){
    if(atMillis<=System.currentTimeMillis()) { activity.toast("La date du rappel est déjà passée."); return false; }
    Intent i=new Intent(activity,ReminderReceiver.class).setAction(ReminderReceiver.ACTION_REMINDER);
    i.putExtra("title",title==null?"Aura":title); i.putExtra("message",message==null?"Rappel Aura":message);
    int id=(int)(atMillis ^ (atMillis>>>32));
    PendingIntent pi=PendingIntent.getBroadcast(activity,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    AlarmManager am=(AlarmManager)activity.getSystemService(Context.ALARM_SERVICE);
    if(am==null) { activity.toast("Le système de rappels Android est indisponible."); return false; }
    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,atMillis,pi);
    persistReminder(atMillis,title==null?"Aura":title,message==null?"Rappel Aura":message,id);
    activity.toast("Rappel enregistré.");
    return true;
  }

  private void persistReminder(long at,String title,String message,int id){
    android.content.SharedPreferences p=activity.getSharedPreferences("aura_reminders",Context.MODE_PRIVATE);
    String old=p.getString("items","");
    String line=at+"|"+safe(title)+"|"+safe(message)+"|"+id;
    p.edit().putString("items",old.isEmpty()?line:old+"\n"+line).apply();
  }
  private String safe(String s){return String.valueOf(s).replace("|"," ").replace("\n"," ");}

  @JavascriptInterface public boolean createGoogleCalendarEvent(String title,long startMillis,long endMillis,int reminderMinutes){
    if(Build.VERSION.SDK_INT>=23 && (activity.checkSelfPermission(Manifest.permission.READ_CALENDAR)!=PackageManager.PERMISSION_GRANTED || activity.checkSelfPermission(Manifest.permission.WRITE_CALENDAR)!=PackageManager.PERMISSION_GRANTED)){ activity.requestPermissions(new String[]{Manifest.permission.READ_CALENDAR,Manifest.permission.WRITE_CALENDAR}, MainActivity.REQ_CALENDAR); return false; }
    try{
      android.database.Cursor c=activity.getContentResolver().query(CalendarContract.Calendars.CONTENT_URI,new String[]{CalendarContract.Calendars._ID,CalendarContract.Calendars.ACCOUNT_TYPE,CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL},CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL+">=?",new String[]{String.valueOf(CalendarContract.Calendars.CAL_ACCESS_EDITOR)},CalendarContract.Calendars._ID+" ASC");
      long calendarId=-1;
      if(c!=null){while(c.moveToNext()){long id=c.getLong(0);String type=c.getString(1);if("com.google".equalsIgnoreCase(type)){calendarId=id;break;}if(calendarId<0)calendarId=id;}c.close();}
      if(calendarId<0){activity.toast("Aucun agenda Google modifiable trouvé.");return false;}
      ContentValues v=new ContentValues();v.put(CalendarContract.Events.DTSTART,startMillis);v.put(CalendarContract.Events.DTEND,endMillis);v.put(CalendarContract.Events.TITLE,title==null?"Aura":title);v.put(CalendarContract.Events.CALENDAR_ID,calendarId);v.put(CalendarContract.Events.EVENT_TIMEZONE,java.util.TimeZone.getDefault().getID());
      Uri eventUri=activity.getContentResolver().insert(CalendarContract.Events.CONTENT_URI,v);if(eventUri==null)return false;
      if(reminderMinutes>=0){ContentValues rv=new ContentValues();rv.put(CalendarContract.Reminders.EVENT_ID,Long.parseLong(eventUri.getLastPathSegment()));rv.put(CalendarContract.Reminders.MINUTES,reminderMinutes);rv.put(CalendarContract.Reminders.METHOD,CalendarContract.Reminders.METHOD_ALERT);activity.getContentResolver().insert(CalendarContract.Reminders.CONTENT_URI,rv);}
      activity.toast("Événement ajouté à Google Agenda.");return true;
    }catch(Exception e){activity.toast("Agenda indisponible : "+e.getMessage());return false;}
  }

  @JavascriptInterface public void openChatGPT(){
    try{
      Intent launch=activity.getPackageManager().getLaunchIntentForPackage("com.openai.chatgpt");
      if(launch!=null){ activity.startActivity(launch); return; }
    }catch(Exception ignored){}
    try{activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://chatgpt.com/")));}
    catch(Exception e){activity.toast("Impossible d’ouvrir ChatGPT.");}
  }
  @JavascriptInterface public boolean chatGPTBridgeEnabled(){ return activity.isChatGPTBridgeEnabled(); }
  @JavascriptInterface public void sendToChatGPT(String text){ activity.sendToChatGPT(text); }
  @JavascriptInterface public void openChatGPTAccessibilitySettings(){ activity.openAccessibilitySettings(); }

  @JavascriptInterface public void openUrl(String url){
    try{activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));}catch(Exception e){activity.toast("Impossible d'ouvrir ce lien.");}
  }

  @JavascriptInterface public void call(String number){
    try{activity.startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+Uri.encode(number))));}catch(Exception e){activity.toast("Impossible d'ouvrir le téléphone.");}
  }

  @JavascriptInterface public void email(String address){
    try{activity.startActivity(new Intent(Intent.ACTION_SENDTO,Uri.parse("mailto:"+Uri.encode(address))));}catch(Exception e){activity.toast("Impossible d'ouvrir la messagerie.");}
  }

  @JavascriptInterface public void pickConversationExport(){ activity.pickImport(); }
  @JavascriptInterface public void configureApiKey(){ activity.runOnUiThread(activity::askKey); }
  @JavascriptInterface public void saveVerbatim(String json){ activity.saveVerbatim(json); }
  @JavascriptInterface public String loadVerbatim(){ return activity.loadVerbatim(); }
  @JavascriptInterface public boolean chatGPTBridgeSourceLogExists(){ return new java.io.File(activity.getFilesDir(),"aura-memory/chatgpt-bridge-verbatim.jsonl").exists(); }
  @JavascriptInterface public void saveAiConfig(String name,String provider,String model,String gateway){ activity.saveAiConfig(name,provider,model,gateway); }
  @JavascriptInterface public void configureModule(String moduleId,String title,String secretName,String secretHint){ activity.configureModule(moduleId,title,secretName,secretHint); }
  @JavascriptInterface public boolean moduleSecretConfigured(String moduleId,String secretName){ return activity.moduleSecretConfigured(moduleId,secretName); }
  @JavascriptInterface public boolean moduleEnabled(String moduleId){ return activity.isModuleEnabled(moduleId); }
  @JavascriptInterface public void publishAuraEvent(String type,String json){ try { java.util.Map<String,Object> data=new java.util.LinkedHashMap<>(); data.put("json",json==null?"":json); activity.getAuraEventBus().publish(new com.aura.sdk.AuraEvent(type,"web","*",data)); } catch(Exception ignored) {} }
  @JavascriptInterface public void setModuleEnabled(String moduleId,boolean enabled){ activity.setModuleEnabled(moduleId,enabled); }
  @JavascriptInterface public void requestPermissions(){ activity.requestNotificationPermission(); if(Build.VERSION.SDK_INT>=23 && activity.checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) activity.requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MainActivity.REQ_MIC); }
  @JavascriptInterface public void requestMicrophonePermission(){ if(Build.VERSION.SDK_INT>=23 && activity.checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) activity.requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MainActivity.REQ_MIC); }
  @JavascriptInterface public void requestNotificationPermission(){ activity.requestNotificationPermission(); }
  @JavascriptInterface public void startAuraService(){ activity.startAuraService(); }
  @JavascriptInterface public void stopAuraService(){ activity.stopAuraService(); }
  @JavascriptInterface public boolean notificationsEnabled(){ return Build.VERSION.SDK_INT<33 || activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED; }
  void shutdown(){}
}
