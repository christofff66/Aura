# Aura — registre des capacités développables ultérieurement

- orchestration multi-IA OpenAI / Claude / Gemini ;
- comparaison de réponses et conclusion propre à Aura ;
- recherche sémantique du corpus ;
- connecteurs et plugins dynamiques ;
- actions Android avec preuve d'exécution ;
- voix temps réel ;
- synchronisation et chiffrement ;
- auto-observation de l'usage et génération de propositions d'interface ;
- évolution contrôlée du noyau lorsque nécessaire à une évolution validée.
