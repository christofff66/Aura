# Aura — découverte et évolution des capacités V2

Aura peut identifier qu'une capacité lui manque et préparer son intégration. Elle ne doit pas télécharger, installer, activer ou exécuter silencieusement une nouvelle capacité privilégiée.

Chaîne : `besoin → recherche/découverte → vérification de la source → fiche de capacité → dépendances/permissions → proposition → autorisation adaptée → installation/intégration → tests → activation → journal`.

Une capacité peut être fournie par un SDK officiel, un connecteur ou un plugin compatible. Le registre est la source de vérité des capacités connues par Aura.

Une évolution d'interface peut déclencher une proposition de capacité. Une autorisation d'interface ne transfère pas automatiquement une permission Android, un accès aux données, un accès réseau ou un droit de modification du noyau.

Pour les fournisseurs IA, les SDK restent côté Gateway lorsque cela protège les secrets. Le client Android ne reçoit pas les clés fournisseurs.
