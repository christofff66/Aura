# Aura — auto-évolution contrôlée de l’interface V1

## Capacité native

Aura possède une capacité déclarée `ui.self_evolution`. Elle est disponible dans le noyau, mais **désactivée par défaut**. Elle devient active uniquement lorsque Christophe accorde explicitement le droit d’évolution de l’interface.

## Ce qu’Aura peut faire avec ce droit

- observer les besoins d’usage et les capacités disponibles ;
- proposer une nouvelle organisation ;
- générer une prévisualisation déclarative ;
- créer une version de manifeste UI ;
- appliquer une version autorisée ;
- journaliser la modification ;
- revenir à une version précédente.

## Limite

Ce droit concerne l’interface. Il n’autorise pas Aura à modifier silencieusement son noyau de sécurité, ses principes, ses sources, ses permissions ou ses données. Ces domaines restent protégés par des contrôles distincts.

## Chaîne

`besoin détecté → proposition → prévisualisation → autorisation → application → vérification → journal → rollback possible`

Une proposition refusée reste conservée comme historique, mais n’est pas appliquée.
