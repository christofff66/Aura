# Aura — stockage local du verbatim V1

Aura conserve localement une copie persistante de son état conversationnel dans le fichier privé Android `aura-memory/verbatim.json` (dans le stockage interne de l’application).

Le fichier contient notamment `exchanges`, avec pour chaque message : identifiant, conversation, date/heure, rôle, contenu et provenance. Les messages utilisateur et les réponses d’Aura sont donc conservés sur le téléphone.

Le navigateur WebView conserve également une copie locale comme mécanisme de secours. La copie native est la source de persistance prioritaire au démarrage.

Le fichier est dans l’espace privé de l’application : il n’est pas exposé comme un fichier public de la carte SD. Une future fonction d’export pourra permettre de récupérer le verbatim explicitement.

## ChatGPT bridge — source log V2

Lorsque le **Pont ChatGPT** est activé par l'utilisateur dans Android, `ChatGPTAccessibilityService` observe uniquement la fenêtre ChatGPT actuellement visible et conserve les changements de contenu sous forme de snapshots verbatim immuables dans `aura-memory/chatgpt-bridge-verbatim.jsonl`.

Chaque entrée contient : source, date/heure, SHA-256, type `ui_snapshot` et contenu brut. Le snapshot est une **source primaire** : il n'est pas présenté comme une séparation certaine entre message utilisateur et réponse assistant. Une couche ultérieure pourra structurer ces sources sans les remplacer.

Le pont est donc : **ChatGPT Android → AccessibilityService → journal local AURA**, sans API OpenAI et sans MCP.
