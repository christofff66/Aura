# Aura — Import multi-IA V1

Aura conserve les exportations externes comme **sources** et ne les transforme pas automatiquement en vérités ou mémoires validées.

## Sources visées
- ChatGPT : JSON d'export, y compris `mapping` / `conversations`.
- Claude : JSON d'export avec `chat_messages` / `chatMessages`.
- Gemini : JSON/Takeout et structures usuelles `messages`, `turns`, `history`, `contents`.
- Formats génériques JSON avec `role` + `content/text`.
- HTML/TXT : import de secours en blocs textuels.
- ZIP Android : Aura extrait localement les JSON/HTML/TXT du paquet puis les analyse.

## Règles
- L'original reste une source.
- Chaque échange conserve une provenance `import:<fournisseur>`.
- Les doublons sont filtrés de façon déterministe pendant un même import.
- L'import ne crée pas directement de mémoire VALIDATED.
- Les différences entre formats sont normalisées vers le modèle d'échange Aura.
- Un format inconnu est importé prudemment en `generic`/`unknown`, sans invention.

## Limite V1
Les formats d'export pouvant évoluer, Aura doit conserver le fichier/source importé et journaliser le fournisseur détecté. Une future couche d'adaptateurs versionnés pourra affiner chaque format sans modifier les sources déjà conservées.
