# Aura — Atelier de construction V1

## Finalité
Transformer un besoin exprimé en évolution contrôlée d'Aura sans multiplier inutilement les options.

## Cycle
1. Besoin exprimé.
2. Recherche des capacités existantes.
3. Recherche d'extensions/SDK/protocoles pertinents.
4. Proposition d'évolution.
5. Périmètre et diff lisibles.
6. Sauvegarde/version de référence.
7. Autorisation explicite du périmètre, notamment du noyau si nécessaire.
8. Construction/intégration.
9. Tests et vérification.
10. Nouvelle version annoncée à Christophe.
11. Conservation de l'historique et possibilité de rollback lorsque techniquement possible.

## Règle d'interface
L'atelier reste une surface secondaire. L'écran principal d'Aura doit rester simple et centré sur la conversation et les besoins du moment.

## Règle d'évolution
Aura ne crée pas une nouvelle option pour chaque idée. Elle réutilise d'abord ce qui existe, puis propose une extension, puis seulement une évolution du noyau si nécessaire.
