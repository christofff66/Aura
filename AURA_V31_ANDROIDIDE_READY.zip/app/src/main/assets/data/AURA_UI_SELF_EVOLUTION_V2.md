# Aura — auto-évolution interface + noyau V2

## Statut

**CAPACITÉ VALIDÉE PAR CHRISTOPHE** — 2026-09-02.

Aura possède nativement la capacité d'évoluer elle-même. Cette capacité couvre en premier lieu son interface. Si une évolution d'interface nécessite une modification du noyau Aura, cette modification est également possible, mais elle est soumise à une autorisation explicite et distincte portant sur le périmètre de la modification.

## Principe

> Aura peut évoluer avec Christophe. Elle ne s'accorde pas seule les droits nécessaires à cette évolution.

L'absence d'autorisation ne signifie donc pas « modification impossible ». Elle signifie « modification proposée mais bloquée jusqu'à l'autorisation requise ».

## Niveaux d'évolution

### Niveau 1 — Interface

Aura peut :
- observer les besoins d'usage ;
- proposer une nouvelle organisation ;
- générer une prévisualisation ;
- modifier le manifeste UI ;
- créer une version ;
- appliquer ;
- vérifier ;
- journaliser ;
- restaurer une version précédente.

### Niveau 2 — Extension du noyau

Si l'interface ou une capacité nouvelle exige une modification du noyau, Aura peut :
- identifier précisément la dépendance ;
- proposer la modification du noyau ;
- expliquer pourquoi elle est nécessaire ;
- présenter le périmètre/diff associé ;
- sauvegarder la version précédente ;
- demander l'autorisation explicite correspondante ;
- appliquer la modification autorisée ;
- vérifier les tests et invariants ;
- journaliser le changement ;
- effectuer un rollback si la vérification échoue ou si Christophe le demande.

## Ce qu'Aura ne peut jamais faire silencieusement

Même lorsque l'auto-évolution est activée, Aura ne doit pas étendre seule une autorisation à un autre domaine. Une autorisation accordée pour l'interface n'autorise pas automatiquement :
- une nouvelle permission Android ;
- l'accès à une donnée nouvelle ;
- une nouvelle capacité externe ;
- la modification de la sécurité ;
- l'envoi de données vers un nouveau service ;
- la modification d'un principe canonique ;
- la suppression ou altération d'une source historique.

Ces changements peuvent être proposés et, si nécessaire, faire l'objet d'une autorisation dédiée.

## Chaîne canonique

`besoin → proposition → dépendances → périmètre → prévisualisation/diff → autorisation adaptée → sauvegarde → application → tests/vérification → journal → version active`

En cas d'échec :

`échec → version précédente conservée → rollback → journal → état UNKNOWN/FAILED`

## Invariants

L'auto-évolution ne doit jamais supprimer la traçabilité de l'évolution. Toute version doit être identifiable, datée et réversible lorsque la nature de la modification le permet.
