# AURA — MOTEUR DU CYCLE V1

Date : 02/09/2026
Statut : spécification algorithmique de travail.

## Cycle canonique
1. ÉCOUTER — recevoir et conserver la source.
2. COMPRENDRE — extraire intention, faits et contexte sans les confondre.
3. CONSERVER — créer les éléments mémorisables avec leurs sources.
4. STRUCTURER — relier tâches, projets, questions, décisions et temps.
5. ANALYSER — rechercher cohérences, contradictions, hypothèses et éléments manquants.
6. PROPOSER / AGIR — choisir le niveau d'autonomie autorisé.
7. ACTUALISER — enregistrer résultat, évolution et historique.

## Garde-fous
- Avant toute conclusion importante : rechercher au moins un élément pouvant nuancer ou contredire l'hypothèse.
- Ne jamais convertir automatiquement une déduction en décision validée.
- Une question non bloquante reste visible et marquée.
- Une question bloquante interrompt le traitement concerné, explique le blocage et attend l'arbitrage.
- Une action externe passe par capacité + autorisation + exécution + vérification.
- En cas d'incertitude sur un résultat externe : état UNKNOWN, jamais « fait ».

## Sorties possibles
`ANSWER`, `STORE`, `PROPOSE`, `REQUEST_VALIDATION`, `ACT`, `PAUSE_BLOCKED`, `UPDATE_STATE`.

## Boucle de contrôle
Après chaque action significative :
1. vérifier le résultat réel ;
2. comparer avec l'intention ;
3. journaliser ;
4. mettre à jour les objets concernés ;
5. réévaluer les questions ouvertes et priorités.

## Non-résolution silencieuse
Si deux informations incompatibles existent et qu'aucune validation plus récente ne permet de trancher : conserver les deux, signaler la contradiction et demander un arbitrage si elle est bloquante.
