# AURA — MODÈLE DE DONNÉES CANONIQUE V1

Date : 02/09/2026
Base : Spécification opérationnelle V1 + AURA MASTER V1.1
Statut : traduction technique — ne transforme pas les points ouverts en décisions.

## 1. Règle de base
La source brute est immuable dans son rôle de source. Les objets dérivés pointent vers leurs sources et sont versionnables.

## 2. Identifiants communs
Tous les objets possèdent : `id`, `created_at`, `updated_at`, `source_ids` lorsque pertinent, et un statut explicite.

## 3. Schéma conceptuel

### Exchange
`id, conversation_id, timestamp, role, content, attachment_ids, provenance`

### MemoryItem
`id, type, content, status, confidence, valid_from, valid_to, source_ids, version, supersedes, superseded_by`

### Question
`id, formulation, blocking, reason_if_blocking, status, visual_priority, source_ids, reminder_id, created_at, updated_at`

### Decision
`id, formulation, status, source_ids, decided_at, valid_from, valid_to, supersedes`

### Task
`id, objective, context, due_at, priority, status, source_ids, reminder_ids, completion_evidence`

### Reminder
`id, objective, message, schedule, status, sent_at, seen_at, interaction, outcome, postponed_at, followup_at, source_id`

### Project
`id, objective, status, constraints, next_actions, decision_ids, question_ids, history`

### Action
`id, intention, capability_id, authorization, attempt, execution, verification, result, external_reference, timestamps`

### Capability
`id, name, version, permissions, inputs, outputs, availability, authorization_level, usage_log`

### Event / AuditLog
`id, timestamp, actor, event_type, target_id, rule_or_validation_id, before, after, result`

## 4. Relations essentielles
- Exchange → source de MemoryItem, Question, Decision, Task, Project, Action.
- Question → peut référencer un Reminder.
- Task → peut référencer plusieurs Reminder.
- Action → dépend d'une Capability et d'une autorisation applicable.
- Toute évolution significative → Event/AuditLog.

## 5. États normalisés
Question : `OPEN / ANSWERED / DISMISSED / EXPIRED`.
Décision : `VALIDATED / REVISED / OBSOLETE`.
Action : `PLANNED / PREPARED / ATTEMPTED / EXECUTED / VERIFIED / FAILED / UNKNOWN`.

## 6. Contraintes d'intégrité
1. Une source ne peut pas être remplacée par sa synthèse.
2. Une décision révisée conserve son historique.
3. Une action `VERIFIED` doit comporter une preuve ou référence de vérification.
4. Une question bloquante doit comporter une justification.
5. Toute modification significative est journalisée.

## 7. Points ouverts
Ce modèle ne fige pas le stockage local/cloud, le chiffrement, les permissions finales, le modèle IA ni l'interface.
