# Aura Plugin Factory V1

Aura peut proposer des plugins depuis la conversation. Chaque plugin possède un manifeste, des permissions, un schéma de données et du code isolé utilisant uniquement l’API AuraPlugin.

Règles :
- génération depuis la conversation ;
- conservation locale du manifeste et du code ;
- aucun accès direct au réseau, secrets, fichiers, DOM global ou APIs Android ;
- permissions explicites ;
- plugin généré = INACTIF jusqu’à autorisation de l’utilisateur ;
- modification du noyau Aura interdite sans autorisation explicite ;
- journalisation des créations et autorisations.
