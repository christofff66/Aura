# Aura V26.2 — Gold ChatGPT Bridge

Cette version corrige la déclaration XML du service d’accessibilité et conserve l’architecture de conversation Aura avec pont vers l’application ChatGPT officielle.

## Vérifications effectuées
- `android:description` du service est une ressource `@string/...`.
- le service d’accessibilité est déclaré avec `BIND_ACCESSIBILITY_SERVICE` et son intent Android officiel.
- manifest et ressources XML parsés avant livraison.
- version Android : 1.26.2 / versionCode 27.

Une compilation Gradle complète n’est pas possible dans cet environnement car le wrapper Gradle ne peut pas télécharger Gradle 8.9 depuis `services.gradle.org`.
