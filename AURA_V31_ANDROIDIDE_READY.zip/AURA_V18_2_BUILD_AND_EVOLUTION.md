# Aura V18.2 — Build et architecture évolutive

## Ouverture
Ouvrir le dossier racine dans Android Studio. Le projet contient le Gradle Wrapper : `gradlew`, `gradlew.bat` et `gradle/wrapper/gradle-wrapper.jar` + `gradle-wrapper.properties`.

Le wrapper demande Gradle 8.9 à l'environnement Android Studio. Aucun Gradle installé manuellement n'est requis en principe ; le téléchargement nécessite une connexion Internet lors de la première utilisation.

## Architecture
- Core Aura : mémoire, contrôle, audit, bridge natif.
- Module Runtime : capacités déclaratives, manifestes, permissions et secrets.
- Presentation Engine : contenu séparé de sa mise en page.
- Workspace : éléments déplaçables/redimensionnables, préférences persistantes et historique.
- ORA/IA : conversation, voix, calculs, schémas et actions via capacités autorisées.
- Evolution Engine : propositions, aperçu, autorisation, sauvegarde, application, vérification et retour arrière.

## Règle de présentation
Une commande comme « mets les dates en bleu » doit devenir une modification déclarative de présentation, pas une modification du code Android.

## Règle d'évolution
Une évolution d'interface ou d'un module compatible ne doit pas imposer une recompilation du noyau. Une modification du noyau Android reste soumise à autorisation et à une nouvelle construction APK.

## Sécurité
Les secrets des modules doivent rester dans Android Keystore et ne doivent pas être exposés au JavaScript de l'interface.
