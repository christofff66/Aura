# Compiler Aura V18.2

1. Décompresser le ZIP.
2. Ouvrir le dossier racine `Aura` dans Android Studio.
3. Laisser Android Studio effectuer le Gradle Sync. Le projet utilise le Gradle Wrapper et téléchargera Gradle 8.9 si nécessaire.
4. Si Android Studio demande un JDK, utiliser le JDK embarqué/recommandé par Android Studio.
5. `Build > Make Project` puis `Build > Build APK(s)`.

Le ZIP contient le wrapper Gradle et sa configuration; aucune installation manuelle de Gradle n'est normalement nécessaire.
