# Aura V18.2 — correction connexion IA

Cette version part de `AURA_ANDROID_V18_2_VERIFIE_ET_CORRIGE.zip`.

## Fonctionnement attendu
- Le bouton microphone utilise la reconnaissance vocale Android uniquement pour transformer la voix en texte.
- Le texte reconnu est automatiquement envoyé à Aura.
- Aura transmet le message au moteur IA configuré.
- Par défaut, le chemin direct OpenAI est utilisé lorsque la clé API OpenAI est enregistrée dans le stockage sécurisé Android.
- Le modèle par défaut reste `gpt-5.6-luna`.
- Le Gateway Aura reste disponible comme mode alternatif si une URL de Gateway est configurée.

## Corrections réalisées
1. La fenêtre de configuration IA s'affiche réellement au premier lancement lorsqu'aucune IA n'est configurée.
2. La voix ne s'arrête plus après l'ouverture du micro : le texte reconnu est injecté dans la conversation puis envoyé automatiquement à Aura.
3. La lecture de la réponse OpenAI Responses API est rendue plus robuste avec l'analyse JSON native.
4. Le flux texte existant `/api/aura` est conservé : mémoire, contexte récent, préférences et règles Aura sont transmis au moteur.

## Clé API
Dans Android, saisir la clé dans **Préférences IA**. Elle est conservée via le stockage sécurisé Android.

Le placeholder source reste volontairement :
`METTRE ICI LA CLE API`
