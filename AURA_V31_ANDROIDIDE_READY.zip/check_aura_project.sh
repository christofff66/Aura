#!/bin/sh
set -eu
printf '%s\n' 'AURA V31 project check'
test -f settings.gradle
test -f build.gradle
test -f app/build.gradle
test -f gradlew
test -d app/src/main
printf '%s\n' 'OK: project root and Gradle files present.'
grep "versionName '1.31.0'" app/build.gradle >/dev/null && echo 'OK: version 1.31.0'
grep "compileSdk 35" app/build.gradle >/dev/null && echo 'OK: compileSdk 35'
