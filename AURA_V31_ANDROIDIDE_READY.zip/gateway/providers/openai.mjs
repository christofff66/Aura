import OpenAI from 'openai';
export async function generate({apiKey, model, system, input}) {
  const client = new OpenAI({apiKey});
  const r = await client.responses.create({model, instructions: system, input, store: false});
  return {text: r.output_text || '', provider:'openai', model};
}
