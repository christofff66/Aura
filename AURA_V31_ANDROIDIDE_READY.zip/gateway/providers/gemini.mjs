import {GoogleGenAI} from '@google/genai';
export async function generate({apiKey, model, system, input}) {
  const ai = new GoogleGenAI({apiKey});
  const r = await ai.interactions.create({model, input, system_instruction: system});
  return {text:r.output_text || '', provider:'gemini', model};
}
