import Anthropic from '@anthropic-ai/sdk';
export async function generate({apiKey, model, system, input}) {
  const client = new Anthropic({apiKey});
  const r = await client.messages.create({model, max_tokens: 1800, system, messages:[{role:'user',content:input}]});
  const text = (r.content || []).filter(x=>x.type==='text').map(x=>x.text).join('\n');
  return {text, provider:'anthropic', model};
}
