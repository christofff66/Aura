# Aura Gateway — multi-provider SDK layer

Le téléphone ne porte pas les clés des fournisseurs. Il se connecte à ce gateway sécurisé, qui utilise les SDK officiels côté serveur.

Providers pris en charge : OpenAI Responses API, Anthropic Messages API et Google Gemini Interactions API.

## Démarrage

```bash
cp .env.example .env
npm install
npm start
```

Définir au minimum `AURA_GATEWAY_TOKEN` et la clé du provider choisi.

## Pourquoi un gateway ?

Une clé API de fournisseur ne doit pas être embarquée dans l'APK. Le gateway permet à Aura de changer de fournisseur/modèle sans modifier le noyau Android. L'Android peut toutefois rester utilisable en mode local sans IA externe.
