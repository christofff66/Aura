export const capabilities = [
  {id:'ai.openai',kind:'provider',provider:'openai',transport:'official_sdk',permissions:[],risk:'low'},
  {id:'ai.anthropic',kind:'provider',provider:'anthropic',transport:'official_sdk',permissions:[],risk:'low'},
  {id:'ai.gemini',kind:'provider',provider:'gemini',transport:'official_sdk',permissions:[],risk:'low'},
  {id:'ui.self_evolution',kind:'core',transport:'aura_runtime',permissions:['ui.write'],risk:'medium'},
  {id:'core.self_evolution',kind:'core',transport:'aura_runtime',permissions:['core.write'],risk:'high'},
  {id:'android.notifications',kind:'android',transport:'native',permissions:['POST_NOTIFICATIONS'],risk:'medium'},
  {id:'android.microphone',kind:'android',transport:'native',permissions:['RECORD_AUDIO'],risk:'medium'}
];
export function capability(id){return capabilities.find(c=>c.id===id)||null}
