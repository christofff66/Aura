import http from 'node:http';
import {generate as openai} from './providers/openai.mjs';
import {generate as anthropic} from './providers/anthropic.mjs';
import {generate as gemini} from './providers/gemini.mjs';
import {capabilities} from './capabilities/registry.mjs';

const env = process.env;
const port = Number(env.PORT || 8787);
const token = env.AURA_GATEWAY_TOKEN || '';
const providers = {
  openai: {fn:openai, key:env.OPENAI_API_KEY, model:env.OPENAI_MODEL || 'gpt-5'},
  anthropic: {fn:anthropic, key:env.ANTHROPIC_API_KEY, model:env.ANTHROPIC_MODEL || 'claude-sonnet-4-6'},
  gemini: {fn:gemini, key:env.GEMINI_API_KEY, model:env.GEMINI_MODEL || 'gemini-3.7-flash'}
};
const send=(res,status,obj)=>{const b=Buffer.from(JSON.stringify(obj));res.writeHead(status,{'content-type':'application/json; charset=utf-8','content-length':b.length,'cache-control':'no-store'});res.end(b)};
const read=async req=>{let s='';for await(const c of req)s+=c;if(s.length>2_000_000)throw new Error('payload too large');return JSON.parse(s||'{}')};
const authorized=req=>!token || req.headers.authorization === `Bearer ${token}`;
const system=`Tu es Aura. Tu dois respecter le Master Aura: la source reste la source; distinguer observation, compréhension, déduction/hypothèse, proposition, décision et action; ne jamais inventer; ne jamais présenter une action comme exécutée sans vérification; les questions bloquantes doivent être explicitement signalées et expliquer pourquoi elles bloquent; les mémoires dérivées restent traçables vers leurs sources. Réponds en français. Pour les données structurées, respecte strictement le format demandé par l'application.`;
const server=http.createServer(async(req,res)=>{
  try{
    if(req.method==='GET'&&req.url==='/health')return send(res,200,{ok:true,service:'aura-gateway',providers:Object.fromEntries(Object.entries(providers).map(([k,v])=>[k,!!v.key]))});
    if(req.method==='GET'&&req.url==='/v1/capabilities')return send(res,200,{ok:true,capabilities:capabilities.map(c=>({...c,available:c.kind!=='provider'||!!providers[c.provider]?.key}))});
    if(req.method!=='POST'||req.url!=='/v1/aura')return send(res,404,{error:'not_found'});
    if(!authorized(req))return send(res,401,{error:'unauthorized'});
    const body=await read(req);
    const p=String(body.provider||env.DEFAULT_PROVIDER||'openai').toLowerCase();
    const cfg=providers[p]; if(!cfg||!cfg.key)return send(res,503,{error:'provider_not_configured',provider:p});
    const model=body.model||cfg.model;
    const input=typeof body.input==='string'?body.input:JSON.stringify(body.input||{});
    const out=await cfg.fn({apiKey:cfg.key,model,system,input});
    send(res,200,{ok:true,...out});
  }catch(e){send(res,500,{error:'gateway_error',message:String(e?.message||e)})}
});
server.listen(port,'0.0.0.0',()=>console.log(`Aura Gateway listening on :${port}`));
