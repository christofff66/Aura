# Aura V27 — voix native ChatGPT

- Aucun `SpeechRecognizer` Android.
- Aucun `TextToSpeech` Android/Google pour la conversation.
- Le bouton Parler ouvre l’application officielle ChatGPT et demande au pont d’accessibilité Aura de cliquer sur son bouton Voice visible.
- Le transport de conversation reste sans API OpenAI.
- Le pont texte V26.2 est conservé.

La commande de Voice dépend de la structure d’interface visible de l’application ChatGPT et peut nécessiter une adaptation si OpenAI modifie son interface.
