# Fixtures de vérification

Le moteur web reconnaît les structures ChatGPT (`mapping`), Claude (`chat_messages`) et les structures usuelles Gemini/génériques (`messages`, `turns`, `history`, `contents`).

L'import Android accepte JSON, HTML, TXT et ZIP contenant ces formats.
