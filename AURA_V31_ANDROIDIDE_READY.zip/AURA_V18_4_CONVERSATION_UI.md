# Aura V18.4 — Conversation UI

- Version V18.4 visible at the top of the application.
- Conversation is the primary interface, with a ChatGPT-like sequence: user message followed by Aura response.
- Persistent main conversation remains the default.
- Typing indicator while OpenAI is answering.
- Agents are removed from the visible main layout; capabilities remain available internally.
- All secondary areas are reached from the compact menu rather than permanently displayed.
- ChatGPT/OpenAI export import remains available, including ZIP extraction on Android.
