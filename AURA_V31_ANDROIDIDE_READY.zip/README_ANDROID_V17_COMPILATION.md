# Aura V17 — compilation Android Studio

Projet reconstruit à partir de `AURA_ANDROID_V17_RELEASE_CANDIDATE_DEPLOYABLE.zip`.

## Android Studio
1. Décompresser le ZIP.
2. Dans Android Studio : **Open** puis sélectionner le dossier racine `Aura` (celui qui contient `settings.gradle`).
3. Attendre la synchronisation Gradle.
4. Choisir la configuration `app`.
5. **Build > Build APK(s)**.
6. APK debug : `app/build/outputs/apk/debug/app-debug.apk`.

## Connexion OpenAI directe
Dans :
`app/src/main/java/com/aura/app/MainActivity.java`

repérer :
`private static final String OPENAI_API_KEY = "METTRE ICI LA CLE API";`

Remplacer uniquement le texte par votre clé API.

Le modèle configuré est `gpt-5.6-luna`. Le Gateway Aura reste prioritaire si une URL de Gateway est configurée dans l'application.

## Sécurité
Pour un usage réel, il est préférable de passer par le Gateway plutôt que d'embarquer une clé API dans l'APK : une clé intégrée dans une application distribuée peut être extraite.
