# Obtenir Aura.apk

Le dépôt contient maintenant deux chemins simples :

## 1. Sans installer d'outils sur son ordinateur

1. Mettre le projet Aura sur un dépôt GitHub.
2. Ouvrir **Actions**.
3. Choisir **Build Aura APK**.
4. Cliquer sur **Run workflow**.
5. À la fin, télécharger l'artefact `aura-v17-debug-apk`.
6. Décompresser l'artefact et installer `app-debug.apk` sur Android.

Le workflow vérifie que l'APK existe et fournit son SHA-256.

## 2. Pour les vraies versions distribuables

Créer un tag GitHub du type `v1.17.0`.
Le workflow `Release Aura APK` compile `assembleRelease`, produit `Aura.apk` et son empreinte SHA-256, puis les attache à une Release GitHub.

> Le projet fourni ici n'est pas signé avec une clé de publication personnelle. L'APK release généré par le workflow est donc actuellement **unsigned**. Pour une installation Android de production, il faudra ajouter une clé de signature protégée par les secrets GitHub.

## Limite actuelle de l'environnement de construction

Cet environnement de travail ne contient pas le SDK Android ni Gradle localement. La compilation finale doit donc être effectuée par Android Studio ou GitHub Actions.
