# Aura Android V3

Cette version poursuit Aura Android avec un objectif de stabilité et de lancement réel.

## Inclus
- WebView locale pour l'interface Aura
- noyau Aura + corpus canonique embarqué
- cerveau IA via HTTPS
- reconnaissance vocale française avec permission micro
- synthèse vocale
- rappels Android via AlarmManager
- persistance des rappels pour restauration après redémarrage/mise à jour
- notification système et service Aura optionnel au premier plan
- actions contrôlées (ouvrir URL, composer un appel, composer un e-mail)
- import/export côté interface
- clé IA stockée localement dans les préférences de l'application

## Lancer sur Android
1. Ouvrir le dossier `aura-android` dans Android Studio.
2. Laisser Android Studio installer/associer le SDK demandé (compileSdk 35).
3. Synchroniser Gradle.
4. Brancher le téléphone Android avec le débogage USB activé, ou démarrer un émulateur.
5. `Run > Run 'app'`.

## Première utilisation
- Autoriser le microphone si tu utilises la voix.
- Autoriser les notifications si tu veux les rappels système.
- La clé OpenAI est facultative pour le noyau local, mais nécessaire au cerveau IA externe.

## Limites honnêtes
- Aucun APK précompilé n'est inclus : ce dossier est le projet Android source.
- Les actions externes restent contrôlées et limitées aux capacités implémentées.
- Le service de premier plan n'est pas démarré automatiquement : l'utilisateur choisit de garder Aura active.
