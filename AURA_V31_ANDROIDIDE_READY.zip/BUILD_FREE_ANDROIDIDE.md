# AURA V31 — compilation AndroidIDE (gratuit, sans GitHub)

## Pré-requis
- Téléphone Android
- AndroidIDE (ou un fork maintenu compatible avec Gradle/AGP)
- JDK 17
- Android SDK avec Android API 35 / Build Tools adaptés
- Accès Internet uniquement pour installer les composants et télécharger les dépendances Gradle la première fois

## Import
1. Décompresser `AURA_V31_ANDROIDIDE_READY.zip`.
2. Dans AndroidIDE : Open / Import Project.
3. Sélectionner le dossier qui contient directement `settings.gradle` (ce dossier).
4. Laisser AndroidIDE synchroniser Gradle.

## Compilation
Dans le terminal du projet :

    ./gradlew assembleDebug

Si le shell refuse l'exécution :

    bash gradlew assembleDebug

APK attendu :

    app/build/outputs/apk/debug/app-debug.apk

## Vérification
Le projet utilise :
- applicationId : com.aura.app
- minSdk : 26
- targetSdk : 35
- compileSdk : 35
- versionCode : 31
- versionName : 1.31.0
- Android Gradle Plugin : 8.7.3
- Gradle wrapper : 8.9

Le JDK qui exécute Gradle doit être compatible avec AGP 8.7.3 (JDK 17 recommandé).

## Important
`local.properties` n'est volontairement pas inclus : il contient un chemin SDK propre à une machine Windows précédente. AndroidIDE doit utiliser son propre SDK.

Ce ZIP est préparé pour compiler, mais l'APK n'a pas été compilé dans cet environnement ChatGPT : aucun SDK Android/Gradle complet n'y est disponible.
