# Aura V26 — GOLD

Aura V26 abandonne le transport conversationnel par API OpenAI.

## Pont ChatGPT

L’APK peut utiliser un service Android Accessibility explicitement activé par l’utilisateur pour transmettre le texte à l’application officielle ChatGPT actuellement ouverte et récupérer le texte visible de sa réponse.

Le pont ne récupère aucune clé, aucun cookie et aucun jeton de session. Il agit uniquement sur l’interface visible de l’application ChatGPT.

Pour que « même conversation » soit respecté, l’utilisateur doit ouvrir dans ChatGPT la conversation qu’il souhaite poursuivre. Aura ouvre ensuite ChatGPT et transmet les nouveaux messages dans cette conversation.

## Interface

Écran principal = conversation uniquement. Le menu reste disponible derrière ☰. Le fil est défilable verticalement. Une bulle flottante indique temporairement l’état du pont.

## Limite assumée

La couche Accessibility dépend de l’interface actuelle de l’application ChatGPT et peut nécessiter une adaptation si cette interface change.
