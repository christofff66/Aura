# Aura Android V15 — noyau évolutif contrôlé

V15 ajoute une vraie boucle produit dans l'interface :

**besoin → découverte → proposition → périmètre/diff → validation explicite → nouvelle version → vérification → audit/rollback**.

## Ce qui est visible dès le départ
- interface volontairement simple et épurée ;
- catalogue des capacités organisé par domaines ;
- état réel des capacités (EN PLACE / DISPONIBLE / ACTIVE) ;
- onboarding au premier lancement, reportable ;
- accès permanent au catalogue ;
- espace « Aura me propose » ;
- espace « Faire évoluer Aura ».

## Auto-évolution
Aura peut transformer une demande de besoin en proposition structurée. Elle ne doit pas multiplier les options inutilement.

Une nouvelle version n'est considérée comme autorisée qu'après validation explicite. Une évolution de noyau est un périmètre séparé et doit être explicitement inclus.

V15 embarque le protocole et le journal de cette boucle. L'application peut appliquer localement des changements déclaratifs de capacités ; la reconstruction réelle d'un APK/noyau compilé reste une opération de build à effectuer dans un environnement Android/CI autorisé, puis à vérifier avant adoption.

## Environnement
Le SDK embarqué sert de contrat stable pour les extensions. Les adaptateurs peuvent ensuite relier Aura à Android, fichiers, web, MCP, services numériques, objets connectés et dispositifs physiques, avec permissions non transférables et vérification des actions.
