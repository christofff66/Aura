# Aura Android V4

Cette version poursuit le projet Aura avec une base Android plus propre et un chemin de compilation APK reproductible.

## Compiler un APK

### Android Studio
1. Ouvrir ce dossier comme projet Gradle.
2. Attendre la synchronisation.
3. `Build > Build APK(s)`.
4. L'APK debug sera dans `app/build/outputs/apk/debug/`.

### GitHub Actions
Le workflow `.github/workflows/build-apk.yml` permet de compiler automatiquement un APK debug après avoir placé le projet dans un dépôt GitHub, puis `Actions > Build Aura APK > Run workflow`.

## Au premier lancement
- Aura démarre avec son noyau local.
- La clé IA est facultative.
- Les permissions micro/notifications sont demandées explicitement.
- Le service arrière-plan est optionnel et doit être activé par l'utilisateur.

## Limites honnêtes
Cette version ne fournit pas encore une signature Play Store, un backend de production, une synchronisation cloud ou une garantie de compilation dans cet environnement sans SDK Android.
