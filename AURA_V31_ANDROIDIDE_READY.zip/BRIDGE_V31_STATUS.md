# AURA V31 — Pont ChatGPT + mémoire locale

## Ce qui est ajouté
- Capture passive du contenu visible de la conversation ChatGPT Android via `AccessibilityService`.
- Journal append-only local : `files/aura-memory/chatgpt-bridge-verbatim.jsonl`.
- SHA-256 par snapshot pour éviter les doublons et préserver une trace d'intégrité.
- Les snapshots restent des sources primaires : aucune séparation artificielle user/assistant n'est inventée.
- Le pont ne dépend ni de l'API OpenAI ni de MCP.

## Limite réelle
Le build APK n'a pas pu être produit dans cet environnement : le Gradle Wrapper doit télécharger Gradle 8.9 depuis `services.gradle.org`, et cet environnement n'a pas d'accès réseau sortant pour ce téléchargement.

Le code source est prêt ; le test final à faire sur Android est :
1. installer/build debug ;
2. activer le Pont ChatGPT dans Paramètres → Accessibilité ;
3. ouvrir une conversation ChatGPT ;
4. envoyer un message et attendre une réponse ;
5. vérifier la création de `aura-memory/chatgpt-bridge-verbatim.jsonl` ;
6. vérifier que chaque changement de fenêtre/contenu produit une entrée différente.
