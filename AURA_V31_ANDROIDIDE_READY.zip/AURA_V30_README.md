# Aura V30 — Conversation + évolution

V30 est une version conversation-first et sans API OpenAI pour le transport de la conversation.

## Principe
- L’écran principal reste centré sur une conversation naturelle.
- Texte : Aura transmet vers l’application ChatGPT officielle via le pont Android Accessibility lorsqu’il est activé.
- Voix : Aura ouvre/tente de déclencher Voice natif dans l’application ChatGPT. Aura n’utilise pas SpeechRecognizer ni TextToSpeech Android pour la conversation.
- Verbatim : les échanges Aura restent conservés localement.
- Compétences : les icônes autour de l’ovale ouvrent les interfaces spécialisées (planning, tâches, mémoire, archives, atelier).
- Évolution : une conversation peut proposer une nouvelle compétence. Rien n’est activé sans autorisation explicite.

## Limite volontaire
Le pont Accessibility dépend de l’interface visible de l’application ChatGPT et peut nécessiter une adaptation si celle-ci change. L’ouverture directe de ChatGPT reste le repli fiable.

## SDK Windows
`local.properties` utilise :
`C:/Users/SC/AppData/Local/Android/Sdk`
