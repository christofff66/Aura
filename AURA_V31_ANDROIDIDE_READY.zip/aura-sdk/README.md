# Aura Embedded SDK v1

SDK embarqué dans Aura Android pour permettre à Aura de concevoir et gérer des plugins sans modifier silencieusement le noyau.

## Ce que le SDK fournit
- `AuraPlugin` : contrat d'un plugin.
- `AuraPluginContext` : surface contrôlée pour lire/écrire des données, notifier l'utilisateur et demander une permission.
- `AuraPluginBuilder` : construction de manifestes/plugins déclaratifs (id, version, permissions, actions, schéma de données, UI, code).
- `AuraPluginRegistry` : enregistrement, exécution et déchargement de plugins autorisés.

Le moteur conversationnel peut générer un `<AURA_PLUGIN_SPEC>` puis Aura le conserve comme proposition. L'activation reste soumise à l'autorisation de Christophe.

Le SDK n'est volontairement pas un compilateur Android embarqué : générer/compiler une APK ou du code Kotlin/Java complet est une étape de build distincte. Il fournit en revanche le contrat/runtime nécessaire pour que l'atelier d'Aura puisse construire des extensions isolées et les faire évoluer sans toucher au noyau.
