package com.aura.sdk;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/** Minimal embedded, provider-agnostic capability contract for Aura. MIT licensed. */
public interface AuraCapability {
    String id();
    String version();
    String description();
    List<String> permissions();
    Map<String,Object> manifest();
    ActionResult execute(Map<String,Object> input, ExecutionContext context);
    default boolean canExecute(Map<String,Object> input, ExecutionContext context) { return true; }
    default List<String> dependencies() { return Collections.emptyList(); }
}
