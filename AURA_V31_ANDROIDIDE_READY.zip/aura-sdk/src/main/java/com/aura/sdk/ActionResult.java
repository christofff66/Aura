package com.aura.sdk;

import java.util.Collections;
import java.util.Map;

public final class ActionResult {
    public enum State { PLANNED, PREPARED, ATTEMPTED, EXECUTED, VERIFIED, FAILED, UNKNOWN }
    public final State state; public final String message; public final Map<String,Object> evidence;
    private ActionResult(State s, String m, Map<String,Object> e){state=s;message=m;evidence=e==null?Collections.emptyMap():e;}
    public static ActionResult of(State s,String m,Map<String,Object> e){return new ActionResult(s,m,e);}
    public boolean verified(){return state==State.VERIFIED;}
}
