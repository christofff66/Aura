package com.aura.sdk;
import java.util.Collections;import java.util.LinkedHashMap;import java.util.Map;
public final class AuraEvent {
  public final String type, source, target; public final Map<String,Object> data;
  public AuraEvent(String type,String source,String target,Map<String,Object> data){this.type=type;this.source=source;this.target=target;this.data=data==null?Collections.emptyMap():Collections.unmodifiableMap(new LinkedHashMap<>(data));}
}
