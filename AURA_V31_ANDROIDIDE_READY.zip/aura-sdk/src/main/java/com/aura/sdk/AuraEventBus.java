package com.aura.sdk;
import java.util.*;import java.util.concurrent.CopyOnWriteArrayList;
public final class AuraEventBus {
  public interface Listener { void onEvent(AuraEvent event); }
  private final List<Listener> listeners=new CopyOnWriteArrayList<>();
  public void subscribe(Listener l){if(l!=null)listeners.add(l);} public void unsubscribe(Listener l){listeners.remove(l);}
  public void publish(AuraEvent e){if(e==null)return;for(Listener l:listeners){try{l.onEvent(e);}catch(Exception ignored){}}}
}
