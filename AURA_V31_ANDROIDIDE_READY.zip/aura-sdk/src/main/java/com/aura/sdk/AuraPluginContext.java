package com.aura.sdk;

import org.json.JSONObject;

/** Narrow, auditable capabilities exposed to generated plugins. */
public interface AuraPluginContext {
    JSONObject read(String key);
    boolean write(String key, JSONObject value);
    void notifyUser(String message);
    boolean requestPermission(String permission);
}
