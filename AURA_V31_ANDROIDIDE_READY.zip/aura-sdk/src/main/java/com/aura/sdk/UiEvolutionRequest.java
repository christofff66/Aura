package com.aura.sdk;

import java.util.Collections;
import java.util.List;

/** Declarative UI evolution request; application/permissions decide whether it may be applied. */
public final class UiEvolutionRequest {
    public final String id, reason, targetVersion; public final List<String> changes, requiredCoreChanges;
    public UiEvolutionRequest(String i,String r,String v,List<String> c,List<String> k){id=i;reason=r;targetVersion=v;changes=c==null?Collections.emptyList():c;requiredCoreChanges=k==null?Collections.emptyList():k;}
}
