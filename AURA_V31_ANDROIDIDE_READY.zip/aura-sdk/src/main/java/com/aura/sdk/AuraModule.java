package com.aura.sdk;
import java.util.*;
public interface AuraModule {
  String id(); String version(); String name();
  default List<String> permissions(){return Collections.emptyList();}
  default List<String> requiredSecrets(){return Collections.emptyList();}
  default List<String> emittedEvents(){return Collections.emptyList();}
  default List<String> consumedEvents(){return Collections.emptyList();}
  default void onEvent(AuraEvent event,AuraEventBus bus){}
  default Map<String,Object> manifest(){Map<String,Object> m=new LinkedHashMap<>();m.put("id",id());m.put("version",version());m.put("name",name());m.put("permissions",permissions());m.put("requiredSecrets",requiredSecrets());m.put("emittedEvents",emittedEvents());m.put("consumedEvents",consumedEvents());return m;}
}
