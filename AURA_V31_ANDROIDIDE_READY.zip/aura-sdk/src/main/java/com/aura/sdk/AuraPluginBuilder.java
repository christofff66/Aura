package com.aura.sdk;

import org.json.JSONArray;
import org.json.JSONObject;

/** Builder for declarative Aura plugin packages. No direct Android/kernel access. */
public final class AuraPluginBuilder {
    private final JSONObject manifest = new JSONObject();

    public AuraPluginBuilder(String id, String name) {
        try {
            manifest.put("id", id);
            manifest.put("name", name);
            manifest.put("version", "1.0.0");
            manifest.put("permissions", new JSONArray());
            manifest.put("inputs", new JSONArray());
            manifest.put("actions", new JSONArray());
            manifest.put("data_schema", new JSONObject());
            manifest.put("ui", "");
        } catch (Exception ignored) { }
    }

    public AuraPluginBuilder version(String value) { try { manifest.put("version", value); } catch (Exception ignored) {} return this; }
    public AuraPluginBuilder description(String value) { try { manifest.put("description", value); } catch (Exception ignored) {} return this; }
    public AuraPluginBuilder permissions(JSONArray value) { try { manifest.put("permissions", value); } catch (Exception ignored) {} return this; }
    public AuraPluginBuilder inputs(JSONArray value) { try { manifest.put("inputs", value); } catch (Exception ignored) {} return this; }
    public AuraPluginBuilder actions(JSONArray value) { try { manifest.put("actions", value); } catch (Exception ignored) {} return this; }
    public AuraPluginBuilder dataSchema(JSONObject value) { try { manifest.put("data_schema", value); } catch (Exception ignored) {} return this; }
    public AuraPluginBuilder ui(String value) { try { manifest.put("ui", value); } catch (Exception ignored) {} return this; }
    public AuraPluginBuilder code(String value) { try { manifest.put("code", value); } catch (Exception ignored) {} return this; }
    public JSONObject build() { return manifest; }
}
