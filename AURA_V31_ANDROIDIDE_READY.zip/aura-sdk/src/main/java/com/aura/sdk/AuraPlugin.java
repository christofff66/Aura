package com.aura.sdk;

import org.json.JSONObject;

/** Runtime-neutral contract for an Aura plugin. */
public interface AuraPlugin {
    String id();
    String name();
    String version();
    JSONObject manifest();
    void onLoad(AuraPluginContext context);
    JSONObject execute(String action, JSONObject input);
    void onUnload();
}
