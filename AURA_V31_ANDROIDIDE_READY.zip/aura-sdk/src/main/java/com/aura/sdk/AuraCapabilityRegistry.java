package com.aura.sdk;

import java.util.*;

/** Small embedded registry. Plugins are data/code modules, never silent permissions. */
public final class AuraCapabilityRegistry {
    private final Map<String,AuraCapability> capabilities=new LinkedHashMap<>();
    public void register(AuraCapability c){if(c==null||c.id()==null||c.id().isEmpty()) throw new IllegalArgumentException("capability id"); capabilities.put(c.id(),c);}
    public Optional<AuraCapability> find(String id){return Optional.ofNullable(capabilities.get(id));}
    public Collection<AuraCapability> all(){return Collections.unmodifiableCollection(capabilities.values());}
}
