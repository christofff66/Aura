package com.aura.sdk;

import java.util.Set;

public final class ExecutionContext {
    public final Set<String> grantedPermissions;
    public final String authorizationId;
    public final boolean dryRun;
    public ExecutionContext(Set<String> p,String a,boolean d){grantedPermissions=p;authorizationId=a;dryRun=d;}
    public boolean authorizedFor(String permission){return grantedPermissions!=null && grantedPermissions.contains(permission);}
}
