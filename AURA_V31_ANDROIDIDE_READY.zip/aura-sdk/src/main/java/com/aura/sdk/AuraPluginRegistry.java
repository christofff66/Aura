package com.aura.sdk;

import org.json.JSONObject;
import java.util.LinkedHashMap;
import java.util.Map;

/** In-process registry used by Aura to validate and activate authorized plugins. */
public final class AuraPluginRegistry {
    private final Map<String, AuraPlugin> plugins = new LinkedHashMap<>();

    public synchronized void register(AuraPlugin plugin) {
        if (plugin == null || plugin.id() == null || plugin.id().trim().isEmpty()) throw new IllegalArgumentException("Plugin id required");
        plugins.put(plugin.id(), plugin);
    }

    public synchronized boolean contains(String id) { return plugins.containsKey(id); }
    public synchronized JSONObject execute(String id, String action, JSONObject input) {
        AuraPlugin plugin = plugins.get(id);
        if (plugin == null) throw new IllegalArgumentException("Plugin not registered: " + id);
        return plugin.execute(action, input == null ? new JSONObject() : input);
    }

    public synchronized void unload(String id) {
        AuraPlugin plugin = plugins.remove(id);
        if (plugin != null) plugin.onUnload();
    }
}
