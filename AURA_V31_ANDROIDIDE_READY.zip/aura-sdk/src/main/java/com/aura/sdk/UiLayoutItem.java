package com.aura.sdk;
public final class UiLayoutItem { public String id; public int x,y,w,h; public boolean visible=true; public UiLayoutItem(String id,int x,int y,int w,int h){this.id=id;this.x=x;this.y=y;this.w=w;this.h=h;} }
