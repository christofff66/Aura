package com.aura.sdk;
import java.util.*;
public final class AuraModuleRegistry {
 private final Map<String,AuraModule> modules=new LinkedHashMap<>(); private final AuraEventBus bus;
 public AuraModuleRegistry(AuraEventBus bus){this.bus=bus;}
 public void register(AuraModule m){if(m==null||m.id()==null)throw new IllegalArgumentException("module");modules.put(m.id(),m);bus.subscribe(e->{if(e.target==null||e.target.equals("*")||e.target.equals(m.id()))m.onEvent(e,bus);});}
 public Optional<AuraModule> find(String id){return Optional.ofNullable(modules.get(id));} public Collection<AuraModule> all(){return Collections.unmodifiableCollection(modules.values());}
}
