# Aura Android V14 — Catalogue de capacités + onboarding

V14 ajoute une première expérience de lancement centrée sur les capacités : Aura montre ce qui est déjà en place, organise les possibilités par domaines d’intérêt, permet d’activer seulement ce qui est demandé et conserve la possibilité de revenir plus tard.

Le SDK de démarrage `:aura-sdk` reste embarqué dans le projet, open source MIT, et indépendant des fournisseurs d’IA.

## Important
V14 est un prototype Android prêt à être ouvert/compilé dans Android Studio. L’environnement de génération actuel ne contient pas le SDK Android nécessaire pour produire ici un APK.

## V16 — Atelier de construction
- Historique des versions conservé et visible dans Aura.
- Retour contrôlé vers une version antérieure lorsque possible.
- Atelier de construction intégré à l’interface.
- Règle : réutiliser avant d’ajouter, ajouter avant de modifier le noyau.
