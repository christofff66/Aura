# Aura V24

Conversation-first release.

- Continuous main conversation.
- Minimal ChatGPT-like surface.
- Floating temporary activity bubble.
- Existing memory/verbatim/import/action/plugin systems retained in the background.
- Embedded `:aura-sdk` for plugin construction and isolated plugin lifecycle.
- Plugin proposals require explicit authorization before activation.
- Version 1.24.0.

Build with Android Studio. A full Gradle build was not claimed in the generation environment when dependencies are unavailable offline.
