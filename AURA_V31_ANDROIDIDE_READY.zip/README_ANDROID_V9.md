# Aura Android V9 — noyau + interface évolutive + gateway multi-fournisseurs

Cette version ajoute une architecture de connexion IA indépendante du fournisseur.

## Le principe

**Android** ne dépend plus d'un fournisseur unique. Il peut rester local, ou se connecter à un **Aura Gateway** qui utilise les SDK officiels côté serveur.

- OpenAI → SDK officiel JS/TS + Responses API
- Anthropic → SDK officiel TS + Messages API
- Gemini → SDK officiel Google GenAI + Interactions API

Le téléphone choisit le provider et le modèle dans Réglages. Le secret du Gateway est chiffré avec Android Keystore.

## Pourquoi pas mettre les SDK fournisseurs directement dans l'APK ?

Pour Aura, ce serait une mauvaise frontière de sécurité pour les clés permanentes. OpenAI indique explicitement que les clés API ne doivent pas être exposées dans les apps clientes. Le SDK doit donc vivre côté Gateway, et l'APK parle à Aura, pas directement aux secrets fournisseurs.

## Lancer le Gateway

```bash
cd gateway
cp .env.example .env
# renseigner AURA_GATEWAY_TOKEN et au moins une clé fournisseur
npm install
npm start
```

Puis dans Aura : Réglages → Connexion IA → URL du Gateway.

## Évolution d'interface

`app/src/main/assets/data/AURA_UI_MANIFEST_V1.json` définit la couche déclarative. Une future intelligence Aura pourra proposer des modifications de cette couche, mais l'application conserve les garde-fous : validation, versioning, audit et rollback.
