package com.aura.app.core
object StopContract { const val START_HOUR=22; const val END_HOUR=5; const val MESSAGE="Le contrat d'arrêt est actif : arrête la boucle et va dormir." }
