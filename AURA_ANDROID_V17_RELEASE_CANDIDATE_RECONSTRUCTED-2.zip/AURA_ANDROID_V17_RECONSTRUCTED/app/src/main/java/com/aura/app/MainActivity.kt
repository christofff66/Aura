package com.aura.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aura.app.core.*
import com.aura.app.ui.AuraTheme

class MainActivity : ComponentActivity() {
    private val repository = AuraRepository()
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { AuraApp(repository) } }
}

@Composable
private fun AuraApp(repository: AuraRepository) {
    var text by remember { mutableStateOf("") }
    var sources by remember { mutableStateOf(repository.sources()) }
    AuraTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("Aura") }) }) { padding ->
            Column(Modifier.padding(padding).padding(16.dp)) {
                Text("Écouter → Comprendre → Conserver → Structurer → Analyser → Proposer / agir → Actualiser")
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), label = { Text("Verbatim / source") })
                Spacer(Modifier.height(8.dp))
                Button(onClick = { if (text.isNotBlank()) { repository.addSource(AuraSource(kind=SourceKind.VERBATIM, content=text.trim())); text=""; sources=repository.sources() } }) { Text("Conserver") }
                Spacer(Modifier.height(16.dp))
                Text("Sources conservées", style=MaterialTheme.typography.titleMedium)
                LazyColumn { items(sources) { source -> Card(Modifier.fillMaxWidth().padding(vertical=4.dp)) { Column(Modifier.padding(12.dp)) { Text(source.kind.name); Text(source.content); Text(source.createdAt, style=MaterialTheme.typography.labelSmall) } } } }
            }
        }
    }
}
