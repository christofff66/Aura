package com.aura.app.core
class AuraRepository { private val items=mutableListOf<AuraSource>(); fun addSource(source:AuraSource){items+=source}; fun sources():List<AuraSource>=items.toList(); fun canAct(requiresAuthorization:Boolean,authorized:Boolean)=!requiresAuthorization||authorized; fun isWithinStopContract(hour:Int)=hour>=22||hour<5 }
