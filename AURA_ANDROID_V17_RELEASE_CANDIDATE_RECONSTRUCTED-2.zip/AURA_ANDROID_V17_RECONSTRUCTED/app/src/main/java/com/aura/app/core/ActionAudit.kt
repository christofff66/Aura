package com.aura.app.core
enum class ActionState { INTENDED, PROPOSED, ATTEMPTED, EXECUTED, VERIFIED }
data class ActionAudit(val action:String,val state:ActionState,val result:String?=null)
