package com.aura.app.core
data class AuraExport(val schemaVersion:Int=1,val exportedAt:String,val sources:List<AuraSource>,val actions:List<ActionAudit> = emptyList())
