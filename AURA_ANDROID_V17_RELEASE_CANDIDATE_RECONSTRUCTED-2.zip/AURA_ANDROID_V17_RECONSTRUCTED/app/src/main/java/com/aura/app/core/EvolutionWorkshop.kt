package com.aura.app.core
data class EvolutionProposal(val title:String,val reason:String,val requiresKernelChange:Boolean,val authorizationGranted:Boolean=false){fun executable()=!requiresKernelChange||authorizationGranted}
object EvolutionWorkshop { fun validate(proposal:EvolutionProposal)=proposal.executable() }
