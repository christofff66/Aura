package com.aura.app.core
import java.time.Instant
import java.util.UUID
enum class SourceKind { VERBATIM, DOCUMENT, EVENT, FACT, UNDERSTANDING, HYPOTHESIS, PROPOSAL, DECISION, CONTRADICTION, UNCERTAINTY, ACTION }
data class AuraSource(val id:String=UUID.randomUUID().toString(), val kind:SourceKind, val content:String, val createdAt:String=Instant.now().toString(), val validFrom:String?=null, val validUntil:String?=null, val supersedes:String?=null)
