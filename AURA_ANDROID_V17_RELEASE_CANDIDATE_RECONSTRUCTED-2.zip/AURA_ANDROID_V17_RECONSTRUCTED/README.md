# Aura — Android V17 reconstructed release candidate

Reconstruction of the previously described Aura Android release candidate from the canonical Aura Master V1.1 and preserved project decisions.

This is a **reconstruction**, not a byte-for-byte recovery of the missing historical ZIP.

## Included
- Android/Compose application base
- Aura core models and principles
- source/verbatim preservation model
- controlled evolution proposal model
- action audit model
- stop contract 22:00–05:00
- GitHub Actions Android build workflow
- architecture and reconstruction documentation

## Build
Open in Android Studio and sync Gradle. The Gradle wrapper JAR is intentionally not fabricated; the launcher delegates to an installed Gradle.
