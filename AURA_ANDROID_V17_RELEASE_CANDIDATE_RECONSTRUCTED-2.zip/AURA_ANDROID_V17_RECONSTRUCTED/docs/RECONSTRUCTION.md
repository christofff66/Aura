# Reconstruction notes

The historical V17 ZIP was not available in the current file store. This package reconstructs the intended foundation from AURA_MASTER V1.1 and preserved technical decisions. It is not claimed to be byte-for-byte identical to the missing archive.
