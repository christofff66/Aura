# Aura architecture

Core models and rules are independent from the UI. Memory is isolated behind a repository seam so a local-first Room/IndexedDB-equivalent implementation can replace the in-memory reconstruction. Evolution proposals require authorization for kernel changes. External actions follow intention → authorization → execution → verification and are auditable.
